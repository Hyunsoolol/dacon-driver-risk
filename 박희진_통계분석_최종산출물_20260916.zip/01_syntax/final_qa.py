from analysis_core import *
import hashlib,re
tables=json.loads((O/'final_viewer.json').read_text(encoding='utf-8'));checks=[]
def match(got,want,tol=.000501):
    try:return abs(float(got)-float(want))<=tol
    except:return False
ar=pd.read_csv(T/'05_ancova.csv')
for _,a in ar.iterrows():
    name=a.outcome+'_'+a.time
    candidates=[t for t in tables if t and t[0]==['종속변수:'+name] and any(row and row[0]=='group' and len(row)==7 for row in t)]
    fits=[t for t in candidates if any(row and row[0]=='수정된 모형' and row[2]=='2' for row in t)]
    assert len(fits)==1,(name,len(fits))
    row=next(row for row in fits[0] if row[0]=='group')
    ok=match(row[4],a.F) and match(row[6],a.partial_eta2)
    checks.append(dict(check='SPSS ANCOVA F/eta',variable=name,passed=ok));assert ok,(row,a.F)
    intr=[t for t in candidates if any(row and row[0]=='수정된 모형' and row[2]=='3' for row in t)]
    assert len(intr)==1
    row=next(row for row in intr[0] if '*' in row[0]);ok=match(row[4],a.interaction_F);checks.append(dict(check='SPSS slope interaction F',variable=name,passed=ok));assert ok
rt=[t for t in tables if any(row and row[0]=='time * group' for row in t) and 'Greenhouse-Geisser' in str(t)]
assert len(rt)==4,len(rt)
rmd=pd.read_csv(T/'03_rm_anova.csv')
for stem,tab in zip(STEMS,rt):
    for effect in ['Time','Group×Time']:
        start=next(j for j,row in enumerate(tab) if row and row[0]==('time' if effect=='Time' else 'time * group'))
        row=tab[start+1];py=rmd[(rmd.outcome==stem)&(rmd.effect==effect)&(rmd.correction=='GG')].iloc[0]
        # First GG row omits merged effect label: correction, SS, df, MS, F, p, eta.
        ok=match(row[2],py.df1) and match(row[4],py.F) and match(row[6],py.partial_eta2)
        checks.append(dict(check='SPSS RM GG df/F/eta',variable=stem+' '+effect,passed=ok));assert ok,(stem,row,py.to_dict())
import pyreadstat
sv,_=pyreadstat.read_sav(str(O/'validated_analysis.sav'));new=read_new()
sv=sv.set_index('ID');new=new.set_index('ID');assert set(sv.index)==set(new.index)
for v in new.columns:assert np.allclose(sv.loc[new.index,v].to_numpy(float),new[v].to_numpy(float)),v
checks.append(dict(check='SPSS SAV equals validated Excel all cells',passed=True))
manifest=json.loads((O/'source_extract/original_manifest.json').read_text(encoding='utf-8'))
for f in manifest:
    ok=hashlib.sha256((R/'00_original'/f['file']).read_bytes()).hexdigest()==f['sha256'];checks.append(dict(check='Original SHA256',variable=f['file'],passed=ok));assert ok
(O/'final_numerical_qa.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
print('All',len(checks),'numerical/source checks passed')
# Extract exact SPSS LMM rows and write the accompanying comparison.
ts=json.loads((O/'lmm_viewer.json').read_text(encoding='utf-8'));lm=[t for t in ts if t and t[0][0]=='소스' and any(row[0]=='group * time' for row in t if row)]
assert len(lm)==4
res=[]
for stem,tab in zip(STEMS,lm):
    for row in tab:
        if row and row[0] in ['group','time','group * time']:res.append(dict(outcome=stem,effect=row[0],df1=float(row[1]),df2=float(row[2]),F=float(row[3]),SPSS_p=row[4]))
dump('19_LMM_SPSs',res)
