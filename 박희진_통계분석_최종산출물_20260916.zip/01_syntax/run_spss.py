"""Run a saved SPSS syntax through the installed IBM SPSS Python integration."""
from pathlib import Path
import sys
import spss
p=Path(sys.argv[1]).resolve()
spss.Submit(p.read_text(encoding='utf-8-sig'))
print('SPSS syntax completed:',p.name)
spss.StopSPSS()
