﻿* Validated revision2 received 2026-09-16. Preserve original files.
GET DATA /TYPE=XLSX /FILE='C:/projects/박희진/02_output/revision2_20260916/received_RAW_DATA.xlsx'
 /SHEET=NAME 'Rawdata' /CELLRANGE=FULL /READNAMES=ON.
DATASET NAME analysis.
FILTER OFF.
WEIGHT OFF.
SPLIT FILE OFF.
SELECT IF NOT MISSING(group).
EXECUTE.
VALUE LABELS group 0 'Control' 1 'Experimental'.
VARIABLE LABELS c_anx_pre 'Child subjective anxiety baseline' b_anx_pre 'Child behavioral anxiety baseline'
 p_anx_pre 'Caregiver STAI baseline' p_unc_pre 'Caregiver PPUS baseline'
 c_beh_change 'PHBQ-AS item mean at post2'.
SAVE OUTFILE='C:/projects/박희진/02_output/validated_analysis.sav'.
DISPLAY DICTIONARY.
FREQUENCIES VARIABLES=group sex relation p_age p_edu p_income.
