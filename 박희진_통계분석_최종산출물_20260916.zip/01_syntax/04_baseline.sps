﻿* Welch row is primary for independent continuous comparisons; both rows retained.
T-TEST GROUPS=group(0 1) /VARIABLES=age c_anx_pre b_anx_pre p_anx_pre p_unc_pre /ES DISPLAY(TRUE) /CRITERIA=CI(.95).
CROSSTABS /TABLES=group BY sex relation p_age p_edu p_income
 /STATISTICS=CHISQ PHI /CELLS=COUNT ROW EXPECTED /METHOD=EXACT TIMER(5).
* Post-only PHBQ-AS: independent groups, never a paired t test.
T-TEST GROUPS=group(0 1) /VARIABLES=c_beh_change /ES DISPLAY(TRUE) /CRITERIA=CI(.95).
NPAR TESTS /M-W=c_beh_change BY group(0 1).
