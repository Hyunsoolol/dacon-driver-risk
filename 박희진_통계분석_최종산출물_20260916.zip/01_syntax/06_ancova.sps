﻿* c_anx post1: assess slope interaction BEFORE interpreting common slope model.
UNIANOVA c_anx_post1 BY group WITH c_anx_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY
 /DESIGN=group c_anx_pre group*c_anx_pre.
* Common-slope estimates below are diagnostic only if interaction or other assumptions fail.
UNIANOVA c_anx_post1 BY group WITH c_anx_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY DESCRIPTIVE
 /EMMEANS=TABLES(group) WITH(c_anx_pre=MEAN) COMPARE(group) ADJ(LSD)
 /DESIGN=group c_anx_pre.
REGRESSION /STATISTICS=COEFF OUTS R ANOVA CI(95)
 /DEPENDENT c_anx_post1 /METHOD=ENTER group c_anx_pre
 /SAVE PRED(a00pred) RESID(a00res) ZRESID(a00zr) SDRESID(a00sr) COOK(a00cook) LEVER(a00lev) DFBETA SDBETA.
EXAMINE VARIABLES=a00res BY group /PLOT BOXPLOT NPPLOT /STATISTICS DESCRIPTIVES /NOTOTAL.
GRAPH /SCATTERPLOT(BIVAR)=c_anx_pre WITH c_anx_post1 BY group.
GRAPH /SCATTERPLOT(BIVAR)=a00pred WITH a00res.

* c_anx post2: assess slope interaction BEFORE interpreting common slope model.
UNIANOVA c_anx_post2 BY group WITH c_anx_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY
 /DESIGN=group c_anx_pre group*c_anx_pre.
* Common-slope estimates below are diagnostic only if interaction or other assumptions fail.
UNIANOVA c_anx_post2 BY group WITH c_anx_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY DESCRIPTIVE
 /EMMEANS=TABLES(group) WITH(c_anx_pre=MEAN) COMPARE(group) ADJ(LSD)
 /DESIGN=group c_anx_pre.
REGRESSION /STATISTICS=COEFF OUTS R ANOVA CI(95)
 /DEPENDENT c_anx_post2 /METHOD=ENTER group c_anx_pre
 /SAVE PRED(a01pred) RESID(a01res) ZRESID(a01zr) SDRESID(a01sr) COOK(a01cook) LEVER(a01lev) DFBETA SDBETA.
EXAMINE VARIABLES=a01res BY group /PLOT BOXPLOT NPPLOT /STATISTICS DESCRIPTIVES /NOTOTAL.
GRAPH /SCATTERPLOT(BIVAR)=c_anx_pre WITH c_anx_post2 BY group.
GRAPH /SCATTERPLOT(BIVAR)=a01pred WITH a01res.

* b_anx post1: assess slope interaction BEFORE interpreting common slope model.
UNIANOVA b_anx_post1 BY group WITH b_anx_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY
 /DESIGN=group b_anx_pre group*b_anx_pre.
* Common-slope estimates below are diagnostic only if interaction or other assumptions fail.
UNIANOVA b_anx_post1 BY group WITH b_anx_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY DESCRIPTIVE
 /EMMEANS=TABLES(group) WITH(b_anx_pre=MEAN) COMPARE(group) ADJ(LSD)
 /DESIGN=group b_anx_pre.
REGRESSION /STATISTICS=COEFF OUTS R ANOVA CI(95)
 /DEPENDENT b_anx_post1 /METHOD=ENTER group b_anx_pre
 /SAVE PRED(a10pred) RESID(a10res) ZRESID(a10zr) SDRESID(a10sr) COOK(a10cook) LEVER(a10lev) DFBETA SDBETA.
EXAMINE VARIABLES=a10res BY group /PLOT BOXPLOT NPPLOT /STATISTICS DESCRIPTIVES /NOTOTAL.
GRAPH /SCATTERPLOT(BIVAR)=b_anx_pre WITH b_anx_post1 BY group.
GRAPH /SCATTERPLOT(BIVAR)=a10pred WITH a10res.

* b_anx post2: assess slope interaction BEFORE interpreting common slope model.
UNIANOVA b_anx_post2 BY group WITH b_anx_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY
 /DESIGN=group b_anx_pre group*b_anx_pre.
* Common-slope estimates below are diagnostic only if interaction or other assumptions fail.
UNIANOVA b_anx_post2 BY group WITH b_anx_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY DESCRIPTIVE
 /EMMEANS=TABLES(group) WITH(b_anx_pre=MEAN) COMPARE(group) ADJ(LSD)
 /DESIGN=group b_anx_pre.
REGRESSION /STATISTICS=COEFF OUTS R ANOVA CI(95)
 /DEPENDENT b_anx_post2 /METHOD=ENTER group b_anx_pre
 /SAVE PRED(a11pred) RESID(a11res) ZRESID(a11zr) SDRESID(a11sr) COOK(a11cook) LEVER(a11lev) DFBETA SDBETA.
EXAMINE VARIABLES=a11res BY group /PLOT BOXPLOT NPPLOT /STATISTICS DESCRIPTIVES /NOTOTAL.
GRAPH /SCATTERPLOT(BIVAR)=b_anx_pre WITH b_anx_post2 BY group.
GRAPH /SCATTERPLOT(BIVAR)=a11pred WITH a11res.

* p_anx post1: assess slope interaction BEFORE interpreting common slope model.
UNIANOVA p_anx_post1 BY group WITH p_anx_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY
 /DESIGN=group p_anx_pre group*p_anx_pre.
* Common-slope estimates below are diagnostic only if interaction or other assumptions fail.
UNIANOVA p_anx_post1 BY group WITH p_anx_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY DESCRIPTIVE
 /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) ADJ(LSD)
 /DESIGN=group p_anx_pre.
REGRESSION /STATISTICS=COEFF OUTS R ANOVA CI(95)
 /DEPENDENT p_anx_post1 /METHOD=ENTER group p_anx_pre
 /SAVE PRED(a20pred) RESID(a20res) ZRESID(a20zr) SDRESID(a20sr) COOK(a20cook) LEVER(a20lev) DFBETA SDBETA.
EXAMINE VARIABLES=a20res BY group /PLOT BOXPLOT NPPLOT /STATISTICS DESCRIPTIVES /NOTOTAL.
GRAPH /SCATTERPLOT(BIVAR)=p_anx_pre WITH p_anx_post1 BY group.
GRAPH /SCATTERPLOT(BIVAR)=a20pred WITH a20res.

* p_anx post2: assess slope interaction BEFORE interpreting common slope model.
UNIANOVA p_anx_post2 BY group WITH p_anx_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY
 /DESIGN=group p_anx_pre group*p_anx_pre.
* Common-slope estimates below are diagnostic only if interaction or other assumptions fail.
UNIANOVA p_anx_post2 BY group WITH p_anx_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY DESCRIPTIVE
 /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) ADJ(LSD)
 /DESIGN=group p_anx_pre.
REGRESSION /STATISTICS=COEFF OUTS R ANOVA CI(95)
 /DEPENDENT p_anx_post2 /METHOD=ENTER group p_anx_pre
 /SAVE PRED(a21pred) RESID(a21res) ZRESID(a21zr) SDRESID(a21sr) COOK(a21cook) LEVER(a21lev) DFBETA SDBETA.
EXAMINE VARIABLES=a21res BY group /PLOT BOXPLOT NPPLOT /STATISTICS DESCRIPTIVES /NOTOTAL.
GRAPH /SCATTERPLOT(BIVAR)=p_anx_pre WITH p_anx_post2 BY group.
GRAPH /SCATTERPLOT(BIVAR)=a21pred WITH a21res.

* p_unc post1: assess slope interaction BEFORE interpreting common slope model.
UNIANOVA p_unc_post1 BY group WITH p_unc_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY
 /DESIGN=group p_unc_pre group*p_unc_pre.
* Common-slope estimates below are diagnostic only if interaction or other assumptions fail.
UNIANOVA p_unc_post1 BY group WITH p_unc_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY DESCRIPTIVE
 /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) ADJ(LSD)
 /DESIGN=group p_unc_pre.
REGRESSION /STATISTICS=COEFF OUTS R ANOVA CI(95)
 /DEPENDENT p_unc_post1 /METHOD=ENTER group p_unc_pre
 /SAVE PRED(a30pred) RESID(a30res) ZRESID(a30zr) SDRESID(a30sr) COOK(a30cook) LEVER(a30lev) DFBETA SDBETA.
EXAMINE VARIABLES=a30res BY group /PLOT BOXPLOT NPPLOT /STATISTICS DESCRIPTIVES /NOTOTAL.
GRAPH /SCATTERPLOT(BIVAR)=p_unc_pre WITH p_unc_post1 BY group.
GRAPH /SCATTERPLOT(BIVAR)=a30pred WITH a30res.

* p_unc post2: assess slope interaction BEFORE interpreting common slope model.
UNIANOVA p_unc_post2 BY group WITH p_unc_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY
 /DESIGN=group p_unc_pre group*p_unc_pre.
* Common-slope estimates below are diagnostic only if interaction or other assumptions fail.
UNIANOVA p_unc_post2 BY group WITH p_unc_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY DESCRIPTIVE
 /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) ADJ(LSD)
 /DESIGN=group p_unc_pre.
REGRESSION /STATISTICS=COEFF OUTS R ANOVA CI(95)
 /DEPENDENT p_unc_post2 /METHOD=ENTER group p_unc_pre
 /SAVE PRED(a31pred) RESID(a31res) ZRESID(a31zr) SDRESID(a31sr) COOK(a31cook) LEVER(a31lev) DFBETA SDBETA.
EXAMINE VARIABLES=a31res BY group /PLOT BOXPLOT NPPLOT /STATISTICS DESCRIPTIVES /NOTOTAL.
GRAPH /SCATTERPLOT(BIVAR)=p_unc_pre WITH p_unc_post2 BY group.
GRAPH /SCATTERPLOT(BIVAR)=a31pred WITH a31res.
