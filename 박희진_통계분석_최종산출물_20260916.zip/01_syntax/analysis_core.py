"""Independent numerical audit. Effects are experimental minus control.
RM ANOVA uses Type III hypotheses via orthonormal within-subject contrasts.
Never alters received data. No data-dependent selection of primary outcomes.
"""
from pathlib import Path
import sys,json,math,itertools
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'02_output/python_packages'))
import numpy as np,pandas as pd,scipy.stats as st
import statsmodels.api as sm
from statsmodels.stats.diagnostic import het_breuschpagan
from statsmodels.stats.multitest import multipletests
import openpyxl
O=R/'02_output';T=R/'03_tables'
STEMS=['c_anx','b_anx','p_anx','p_unc']
LABELS={'c_anx':'아동 주관적 불안','b_anx':'아동 행동불안','p_anx':'보호자 불안','p_unc':'보호자 불확실성','c_beh_change':'아동 행동변화'}
def read_new():
    w=openpyxl.load_workbook(O/'revision2_20260916/received_RAW_DATA.xlsx',data_only=True)
    rows=list(w['Rawdata'].values)
    return pd.DataFrame([r for r in rows[1:] if r[0]],columns=rows[0])
def dump(name,rows):
    df=pd.DataFrame(rows);df.to_csv(T/(name+'.csv'),index=False,encoding='utf-8-sig');return df
def rm(d,stem):
    cols=[stem+'_'+t for t in ['pre','post1','post2']]
    q=d[['group']+cols].dropna();Y=q[cols].to_numpy(float);g=q.group.to_numpy(float);n=len(q)
    X=np.column_stack([np.ones(n),g]);V=np.linalg.inv(X.T@X);B=V@X.T@Y;E=Y-X@B
    C=np.array([[-1,1,0],[-1,-1,2]],float);C=C/np.sqrt((C*C).sum(axis=1))[:,None]
    S=C@(E.T@E/(n-2))@C.T
    ev=np.linalg.eigvalsh(S);W=np.prod(ev)/(ev.mean()**2);eps=ev.sum()**2/(2*(ev**2).sum())
    chi=-(n-3)*np.log(W);mauchly_p=st.chi2.sf(chi,2)
    # HF uses the residual degrees of freedom for the between-subject model.
    hf=min(1,(n*2*eps-2)/(2*((n-2)-2*eps)))
    error=np.trace(C@E.T@E@C.T);rows=[]
    for effect,c in [('Time',np.array([1,.5])),('Group×Time',np.array([0,1]))]:
        z=c@B@C.T;SS=z@z/(c@V@c);F=(SS/2)/(error/((n-2)*2));eta=SS/(SS+error)
        for correction,e in [('Sphericity',1),('GG',eps),('HF',hf)]:
            rows.append(dict(outcome=stem,effect=effect,correction=correction,N=n,F=F,df1=2*e,df2=2*(n-2)*e,p=st.f.sf(F,2*e,2*(n-2)*e),partial_eta2=eta))
    fit=sm.OLS(Y.mean(axis=1),X).fit();F=fit.tvalues[1]**2
    rows.append(dict(outcome=stem,effect='Group',correction='NA',N=n,F=F,df1=1,df2=n-2,p=fit.pvalues[1],partial_eta2=F/(F+n-2)))
    return rows,dict(outcome=stem,N=n,W=W,chi2=chi,df=2,p=mauchly_p,GG=eps,HF=hf)
def ancova(d,stem,post):
    q=d[['ID','group',stem+'_pre',stem+'_'+post]].dropna();g=q.group.to_numpy(float);x=q[stem+'_pre'].to_numpy(float);y=q[stem+'_'+post].to_numpy(float);n=len(q)
    X=np.column_stack([np.ones(n),g,x]);fit=sm.OLS(y,X).fit();ci=fit.conf_int();F=fit.tvalues[1]**2
    hc=fit.get_robustcov_results(cov_type='HC3',use_t=True)
    xc=x-x.mean();Xi=np.column_stack([np.ones(n),g,xc,g*xc]);inter=sm.OLS(y,Xi).fit()
    quad=sm.OLS(y,np.column_stack([X,xc**2])).fit()
    inf=fit.get_influence();r=fit.resid
    a=dict(outcome=stem,time=post,N=n,difference=fit.params[1],SE=fit.bse[1],CI_low=ci[1,0],CI_high=ci[1,1],F=F,df1=1,df2=fit.df_resid,p=fit.pvalues[1],partial_eta2=F/(F+fit.df_resid),HC3_SE=hc.bse[1],HC3_low=hc.conf_int()[1,0],HC3_high=hc.conf_int()[1,1],HC3_p=hc.pvalues[1],baseline_mean=x.mean(),slope=fit.params[2],slope_interaction=inter.params[3],interaction_low=inter.conf_int()[3,0],interaction_high=inter.conf_int()[3,1],interaction_F=inter.tvalues[3]**2,interaction_df=n-4,interaction_p=inter.pvalues[3],quadratic_p=quad.pvalues[-1],resid_Shapiro_p=st.shapiro(r).pvalue,BP_p=het_breuschpagan(r,X)[1],resid_Levene_p=st.levene(r[g==0],r[g==1],center='median').pvalue,pearson_r=st.pearsonr(x,y).statistic,pearson_control=st.pearsonr(x[g==0],y[g==0]).statistic,pearson_experimental=st.pearsonr(x[g==1],y[g==1]).statistic,baseline_min_control=x[g==0].min(),baseline_max_control=x[g==0].max(),baseline_min_experimental=x[g==1].min(),baseline_max_experimental=x[g==1].max())
    for group in [0,1]:
        pr=fit.get_prediction(np.array([[1,group,x.mean()]])).summary_frame().iloc[0]
        for k,v in [('mean','mean'),('SE','mean_se'),('low','mean_ci_lower'),('high','mean_ci_upper')]:a[f'adj_{group}_{k}']=pr[v]
    points=[]
    for j,i in enumerate(q.ID):
        cook=inf.cooks_distance[0][j];lev=inf.hat_matrix_diag[j];rs=inf.resid_studentized_external[j];dfb=inf.dfbetas[j,1]
        points.append(dict(outcome=stem,time=post,ID=i,group=g[j],baseline=x[j],post=y[j],predicted=fit.fittedvalues[j],residual=r[j],standardized=inf.resid_studentized_internal[j],studentized=rs,Cook=cook,leverage=lev,DFBETA_group=dfb,flag_Cook=bool(cook>4/n),flag_leverage=bool(lev>6/n),flag_studentized=bool(abs(rs)>3),flag_DFBETA=bool(abs(dfb)>2/np.sqrt(n))))
    return a,points,fit
def welch(a,b):
    n,m=len(a),len(b);va=np.var(a,ddof=1);vb=np.var(b,ddof=1);se=np.sqrt(va/n+vb/m);df=(va/n+vb/m)**2/((va/n)**2/(n-1)+(vb/m)**2/(m-1));diff=np.mean(a)-np.mean(b);crit=st.t.ppf(.975,df)
    sp=np.sqrt(((n-1)*va+(m-1)*vb)/(n+m-2));hedges=(1-3/(4*(n+m)-9))*diff/sp
    return dict(difference=diff,SE=se,df=df,t=diff/se,p=2*st.t.sf(abs(diff/se),df),CI_low=diff-crit*se,CI_high=diff+crit*se,Hedges_g=hedges)
def exact_2xk(table):
    # Fisher-Freeman-Halton two-sided conditional probability ordering, no Monte Carlo.
    table=np.asarray(table,int);tot=table.sum(axis=0);nr=table[0].sum();N=table.sum();den=math.comb(int(N),int(nr));obs=math.prod(math.comb(int(t),int(v)) for t,v in zip(tot,table[0]))/den;p=0
    for prefix in itertools.product(*(range(int(t)+1) for t in tot[:-1])):
        last=nr-sum(prefix)
        if not 0<=last<=tot[-1]:continue
        row=(*prefix,last);pr=math.prod(math.comb(int(t),int(v)) for t,v in zip(tot,row))/den
        if pr<=obs*(1+1e-10):p+=pr
    return min(1,p)
if __name__=='__main__':
    d=read_new();d.to_csv(O/'analysis_data.csv',index=False,encoding='utf-8-sig')
    desc=[];flags=[]
    outcomes=[c for c in d.columns if any(c.startswith(s+'_') for s in STEMS) or c=='c_beh_change']
    for v in outcomes:
        for group in [0,1]:
            q=d[d.group==group];x=q[v].to_numpy(float);n=len(x);q1,q3=np.quantile(x,[.25,.75]);iqr=q3-q1;se=x.std(ddof=1)/np.sqrt(n);t=st.t.ppf(.975,n-1)
            desc.append(dict(variable=v,group=group,N=n,mean=x.mean(),SD=x.std(ddof=1),median=np.median(x),Q1=q1,Q3=q3,IQR=iqr,min=x.min(),max=x.max(),CI_low=x.mean()-t*se,CI_high=x.mean()+t*se,skew=st.skew(x,bias=False),kurtosis=st.kurtosis(x,bias=False),Shapiro_W=st.shapiro(x).statistic,Shapiro_p=st.shapiro(x).pvalue))
            for i,z in zip(q.ID,x):
                if z<q1-1.5*iqr or z>q3+1.5*iqr:flags.append(dict(variable=v,group=group,ID=i,value=z,Q1=q1,Q3=q3,IQR=iqr,extreme=bool(z<q1-3*iqr or z>q3+3*iqr)))
    dump('01_descriptive',desc);dump('02_IQR_candidates',flags)
    rrows=[];spheres=[];arows=[];points=[];changes=[]
    for stem in STEMS:
        rr,ss=rm(d,stem);rrows+=rr;spheres.append(ss)
        for post in ['post1','post2']:
            a,p,_=ancova(d,stem,post);arows.append(a);points+=p
            change=d[stem+'_'+post]-d[stem+'_pre'];changes.append(dict(outcome=stem,time=post,**welch(change[d.group==1],change[d.group==0])))
    aa=dump('05_ancova',arows);dump('06_influence_all',points);dump('03_rm_anova',rrows);dump('04_sphericity',spheres)
    cc=pd.DataFrame(changes);cc['Holm_p_within_outcome']=cc.groupby('outcome')['p'].transform(lambda x:multipletests(x,method='holm')[1]);dump('07_change_scores',cc)
    baseline=[]
    for v in ['age']+[s+'_pre' for s in STEMS]:
        a=d.loc[d.group==1,v].to_numpy(float);b=d.loc[d.group==0,v].to_numpy(float);po=st.ttest_ind(a,b,equal_var=True)
        baseline.append(dict(variable=v,**welch(a,b),pooled_t=po.statistic,pooled_p=po.pvalue,Levene_p=st.levene(a,b,center='mean').pvalue))
    dump('08_baseline_continuous',baseline)
    cats=[]
    for v in ['sex','relation','p_age','p_edu','p_income']:
        tab=pd.crosstab(d.group,d[v]);chi,p,df,expected=st.chi2_contingency(tab,correction=False);fp=exact_2xk(tab)
        cats.append(dict(variable=v,chi2=chi,df=df,Pearson_p=p,Fisher_Freeman_Halton_p=fp,min_expected=expected.min(),fraction_expected_under5=(expected<5).mean(),Cramers_V=np.sqrt(chi/len(d)),counts=json.dumps(tab.to_dict())))
    dump('09_baseline_categorical',cats)
    mw=[]
    for v in ['c_anx_'+t for t in ['pre','post1','post2']]+['b_anx_'+t for t in ['pre','post1','post2']]+['c_beh_change']:
        a=d.loc[d.group==1,v].to_numpy(float);b=d.loc[d.group==0,v].to_numpy(float);u=st.mannwhitneyu(a,b,method='asymptotic',use_continuity=False);mw.append(dict(variable=v,U=min(u.statistic,len(a)*len(b)-u.statistic),p=u.pvalue,rank_biserial=2*u.statistic/(len(a)*len(b))-1,**{'mean_'+k:val for k,val in welch(a,b).items()}))
    mm=pd.DataFrame(mw);mm['Holm_p_3times']=np.nan
    for stem in ['c_anx','b_anx']:
        ix=mm.variable.str.startswith(stem);mm.loc[ix,'Holm_p_3times']=multipletests(mm.loc[ix,'p'],method='holm')[1]
    dump('10_independent_outcome_comparisons',mm)
    # All-case primary, objective diagnostic deletions, robust SE, and unbiased LOO inventory.
    sens=[];loo=[];rsens=[]
    pts=pd.DataFrame(points)
    for stem in ['p_anx','p_unc']:
        base=aa[aa.outcome==stem]
        flagged=pts[(pts.outcome==stem)&(pts.flag_Cook|pts.flag_studentized|pts.flag_DFBETA)]
        eligible=sorted(flagged.ID.unique());(O/(stem+'_influence_candidate_ids.json')).write_text(json.dumps(eligible),encoding='utf8')
        sets=[('A_all',[])]+[(f'B_single_{i}',[i]) for i in eligible]+[('B_joint_influence',eligible)]
        for scenario,omit in sets:
            q=d[~d.ID.isin(omit)]
            rr,sp=rm(q,stem)
            rr=[r for r in rr if (r['effect']=='Group×Time' and r['correction']=='GG')]
            rsens.extend(dict(scenario=scenario,excluded=','.join(omit),**r) for r in rr)
            for post in ['post1','post2']:
                a,_,_=ancova(q,stem,post);sens.append(dict(scenario=scenario,excluded=','.join(omit),**a))
        for i in d.ID:
            q=d[d.ID!=i];rr,sp=rm(q,stem);rr=next(r for r in rr if r['effect']=='Group×Time' and r['correction']=='GG')
            for post in ['post1','post2']:
                a,_,_=ancova(q,stem,post);loo.append(dict(excluded=i,RM_GG_p=rr['p'],RM_eta2=rr['partial_eta2'],**a))
    dump('11_sensitivity_ancova',sens);dump('12_sensitivity_rm',rsens);dump('13_leave_one_out',loo)
    print(aa[['outcome','time','difference','CI_low','CI_high','p','interaction_p','HC3_p']].to_string(index=False))
    print(pd.DataFrame(rrows).query("effect=='Group×Time' and correction=='GG'").to_string(index=False))
