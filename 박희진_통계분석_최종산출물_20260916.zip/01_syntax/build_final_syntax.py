from pathlib import Path
import json,csv
R=Path(__file__).resolve().parents[1];S=R/'01_syntax';O=R/'02_output';root=R.as_posix()
stems=['c_anx','b_anx','p_anx','p_unc'];vars=[s+'_'+t for s in stems for t in ['pre','post1','post2']]+['c_beh_change']
def save(name,body):
    path=S/(name+'.sps');path.write_text(body,encoding='utf-8-sig');return path
init=f"""* Validated revision2 received 2026-09-16. Preserve original files.
GET DATA /TYPE=XLSX /FILE='{root}/02_output/revision2_20260916/received_RAW_DATA.xlsx'
 /SHEET=NAME 'Rawdata' /CELLRANGE=FULL /READNAMES=ON.
DATASET NAME analysis.
FILTER OFF.
WEIGHT OFF.
SPLIT FILE OFF.
SELECT IF NOT MISSING(group).
EXECUTE.
VALUE LABELS group 0 'Control' 1 'Experimental'.
VARIABLE LABELS c_anx_pre 'Child subjective anxiety baseline' b_anx_pre 'Child behavioral anxiety baseline'
 p_anx_pre 'Caregiver STAI baseline' p_unc_pre 'Caregiver PPUS baseline'
 c_beh_change 'PHBQ-AS item mean at post2'.
SAVE OUTFILE='{root}/02_output/validated_analysis.sav'.
DISPLAY DICTIONARY.
FREQUENCIES VARIABLES=group sex relation p_age p_edu p_income.
"""
save('01_data_check',init)
save('03_descriptive',f"""* Full-case summaries. EXAMINE quartiles may use a different interpolation than Python.
EXAMINE VARIABLES={' '.join(vars)} BY group /ID=ID
 /PLOT BOXPLOT HISTOGRAM NPPLOT /COMPARE GROUPS /STATISTICS DESCRIPTIVES
 /CINTERVAL 95 /PERCENTILES(25,50,75) HAVERAGE /MISSING PAIRWISE /NOTOTAL.
""")
save('04_baseline',"""* Welch row is primary for independent continuous comparisons; both rows retained.
T-TEST GROUPS=group(0 1) /VARIABLES=age c_anx_pre b_anx_pre p_anx_pre p_unc_pre /ES DISPLAY(TRUE) /CRITERIA=CI(.95).
CROSSTABS /TABLES=group BY sex relation p_age p_edu p_income
 /STATISTICS=CHISQ PHI /CELLS=COUNT ROW EXPECTED /METHOD=EXACT TIMER(5).
* Post-only PHBQ-AS: independent groups, never a paired t test.
T-TEST GROUPS=group(0 1) /VARIABLES=c_beh_change /ES DISPLAY(TRUE) /CRITERIA=CI(.95).
NPAR TESTS /M-W=c_beh_change BY group(0 1).
""")
rm=[]
for s in stems:
    rm.append(f"""* {s}: primary is group by time; GG and HF appear in the output.
GLM {s}_pre {s}_post1 {s}_post2 BY group
 /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3)
 /PRINT=DESCRIPTIVE ETASQ HOMOGENEITY
 /EMMEANS=TABLES(group*time) COMPARE(group) ADJ(BONFERRONI)
 /EMMEANS=TABLES(group*time) COMPARE(time) ADJ(BONFERRONI)
 /WSDESIGN=time /DESIGN=group.
""")
save('05_rm_anova','\n'.join(rm))
anc=[]
for k,s in enumerate(stems):
    for j,t in enumerate(['post1','post2']):
        tag=f'a{k}{j}'
        anc.append(f"""* {s} {t}: assess slope interaction BEFORE interpreting common slope model.
UNIANOVA {s}_{t} BY group WITH {s}_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY
 /DESIGN=group {s}_pre group*{s}_pre.
* Common-slope estimates below are diagnostic only if interaction or other assumptions fail.
UNIANOVA {s}_{t} BY group WITH {s}_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ HOMOGENEITY DESCRIPTIVE
 /EMMEANS=TABLES(group) WITH({s}_pre=MEAN) COMPARE(group) ADJ(LSD)
 /DESIGN=group {s}_pre.
REGRESSION /STATISTICS=COEFF OUTS R ANOVA CI(95)
 /DEPENDENT {s}_{t} /METHOD=ENTER group {s}_pre
 /SAVE PRED({tag}pred) RESID({tag}res) ZRESID({tag}zr) SDRESID({tag}sr) COOK({tag}cook) LEVER({tag}lev) DFBETA SDBETA.
EXAMINE VARIABLES={tag}res BY group /PLOT BOXPLOT NPPLOT /STATISTICS DESCRIPTIVES /NOTOTAL.
GRAPH /SCATTERPLOT(BIVAR)={s}_pre WITH {s}_{t} BY group.
GRAPH /SCATTERPLOT(BIVAR)={tag}pred WITH {tag}res.
""")
save('06_ancova','\n'.join(anc))
change=[]
for s in stems:
    for t in ['post1','post2']:change.append(f'COMPUTE {s}_d{t[-1]}={s}_{t}-{s}_pre.')
change.append('T-TEST GROUPS=group(0 1) /VARIABLES='+' '.join(s+'_d'+i for s in stems for i in ['1','2'])+' /ES DISPLAY(TRUE) /CRITERIA=CI(.95).')
save('07_change_scores','* Supplementary changes; Holm adjustment across two post-time comparisons per outcome is in tables.\n'+'\n'.join(change))
sens=['* Diagnostic deletions, never the primary analysis. All IDs were selected by influence thresholds, not p values.']
for s in ['p_anx','p_unc']:
    ids=json.loads((O/(s+'_influence_candidate_ids.json')).read_text())
    for label,omit in [('all',[])]+[(i,[i]) for i in ids]+[('joint',ids)]:
        sens.append(f"* {s} scenario {label}.")
        expr=' AND '.join("ID <> '"+i+"'" for i in omit) or '1'
        sens.append(f'COMPUTE sensitivity_filter=({expr}).\nFILTER BY sensitivity_filter.')
        sens.append(f'GLM {s}_pre {s}_post1 {s}_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.')
        for t in ['post1','post2']:
            sens.append(f'UNIANOVA {s}_{t} BY group WITH {s}_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH({s}_pre=MEAN) COMPARE(group) /DESIGN=group {s}_pre.')
        sens.append('FILTER OFF.')
save('08_outlier_sensitivity','\n'.join(sens))
files=['01_data_check','03_descriptive','04_baseline','05_rm_anova','06_ancova','07_change_scores']
master=['* Run from any directory. Full validated cohort.','OUTPUT NEW.']+[f"INSERT FILE='{root}/01_syntax/{f}.sps'." for f in files]
master += [f"OUTPUT SAVE OUTFILE='{root}/02_output/02_final_verified.spv'.",f"OUTPUT EXPORT /CONTENTS EXPORT=ALL /HTML DOCUMENTFILE='{root}/02_output/final_viewer.html'."]
save('00_run_final','\n'.join(master))
save('00_run_sensitivity',f"OUTPUT NEW.\nGET FILE='{root}/02_output/validated_analysis.sav'.\nINSERT FILE='{root}/01_syntax/08_outlier_sensitivity.sps'.\nOUTPUT SAVE OUTFILE='{root}/02_output/03_sensitivity.spv'.\nOUTPUT EXPORT /CONTENTS EXPORT=ALL /HTML DOCUMENTFILE='{root}/02_output/sensitivity_viewer.html'.")
print('Saved SPSS scripts')
