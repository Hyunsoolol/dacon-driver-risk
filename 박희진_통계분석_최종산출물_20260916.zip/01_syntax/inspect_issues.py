exec((__import__('pathlib').Path(__file__).parent/'01_data_check.py').read_text(encoding='utf-8').split('issues=[]')[0])
out=[]
for s in w:
    for row in s:
        if row[0].value in ['C29','C30','E03','C13','E11'] and s.title not in ['명단']:
            if s.title=='Rawdata':continue
            if s.title=='코드표':continue
            if s==w.worksheets[0]:continue
            if (row[0].value in ['C29','C30','E03'] and s.title=='보호자 불안 설문지(사전)') or (row[0].value=='C13' and s.title=='보호자 불확실성 설문지(사전)') or (row[0].value=='E11' and '불안' in s.title and '사후2' in s.title):
                out.append({'sheet':s.title,'ID':row[0].value,'cells':[(c.coordinate,c.value,wc[s.title][c.coordinate].value) for c in row]})
(O/'issues_cell_details.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2,default=str))
