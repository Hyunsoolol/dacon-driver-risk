﻿* Full-case summaries. EXAMINE quartiles may use a different interpolation than Python.
EXAMINE VARIABLES=c_anx_pre c_anx_post1 c_anx_post2 b_anx_pre b_anx_post1 b_anx_post2 p_anx_pre p_anx_post1 p_anx_post2 p_unc_pre p_unc_post1 p_unc_post2 c_beh_change BY group /ID=ID
 /PLOT BOXPLOT HISTOGRAM NPPLOT /COMPARE GROUPS /STATISTICS DESCRIPTIVES
 /CINTERVAL 95 /PERCENTILES(25,50,75) HAVERAGE /MISSING PAIRWISE /NOTOTAL.
