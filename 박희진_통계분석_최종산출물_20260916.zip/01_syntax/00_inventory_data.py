from pathlib import Path
import sys,json
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'02_output/python_packages'))
import pyreadstat,openpyxl
d,m=pyreadstat.read_sav(str(next((R/'00_original').glob('*.sav'))))
o=R/'02_output/source_extract'
d.to_csv(o/'sav_values.csv',index=False,encoding='utf-8-sig')
(o/'sav_dictionary.json').write_text(json.dumps(m.__dict__,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
print('SAV shape',d.shape,'columns',list(d.columns))
w=openpyxl.load_workbook(next((R/'00_original').glob('*.xlsx')),data_only=False)
rows={s.title: {'rows':s.max_row,'cols':s.max_column,'cells':[[c.coordinate,c.value] for row in s for c in row if c.value is not None]} for s in w}
(o/'excel_cells.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
for s in w:
    print('SHEET',s.title,s.max_row,s.max_column)
    for row in s.iter_rows(min_row=1,max_row=6):print([(c.coordinate,c.value) for c in row if c.value is not None])
