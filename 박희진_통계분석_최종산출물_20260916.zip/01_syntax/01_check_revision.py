from pathlib import Path
import openpyxl,json,re,hashlib,shutil,collections,csv
R=Path(__file__).resolve().parents[1]
src=next(Path('C:/Users/shs70/.codex/codex-remote-attachments/01a09fa5-3b17-7cc2-adc4-3baac1b96886/E3E947E2-411D-4DBC-8F38-88BE2545F622').glob('*.xlsx'))
out=R/'02_output/revision_20260916';out.mkdir(exist_ok=True)
dest=out/'received_RAW_DATA.xlsx'
if not dest.exists():shutil.copy2(src,dest)
assert hashlib.sha256(src.read_bytes()).digest()==hashlib.sha256(dest.read_bytes()).digest()
old=openpyxl.load_workbook(next((R/'00_original').glob('*.xlsx')),data_only=False)
new=openpyxl.load_workbook(dest,data_only=False)
cache=openpyxl.load_workbook(dest,data_only=True)
changes=[]
for s in new:
    if s.title not in old.sheetnames:continue
    a=old[s.title]
    for row in s:
        for c in row:
            before=a[c.coordinate].value
            if before!=c.value:
                changes.append(dict(sheet=s.title,cell=c.coordinate,ID=s.cell(c.row,1).value,old=before,new=c.value))
raw=cache['Rawdata'];headers=[c.value for c in raw[1]]
records=[dict(zip(headers,row)) for row in raw.iter_rows(min_row=2,values_only=True) if any(v is not None for v in row)]
ids=[r['ID'] for r in records];byid={r['ID']:r for r in records}
issues=[];summaries=[]
bounds={'group':(0,1),'age':(4,6),'sex':(1,2),'relation':(1,5),'p_age':(1,4),'p_edu':(1,3),'p_income':(1,4),'c_beh_change':(1,5)}
for h in headers:
    for stem,lo,hi in [('c_anx',0,10),('b_anx',5,22),('p_anx',20,80),('p_unc',22,88)]:
        if h.startswith(stem):bounds[h]=(lo,hi)
for r in records:
    for h,(lo,hi) in bounds.items():
        v=r[h]
        if not isinstance(v,(int,float)) or not lo<=v<=hi:issues.append(dict(type='Rawdata_range_missing',ID=r['ID'],variable=h,value=v))
        elif h!='c_beh_change' and v!=int(v):issues.append(dict(type='noninteger',ID=r['ID'],variable=h,value=v))
        elif h.startswith('c_anx') and v not in [0,2,4,6,8,10]:issues.append(dict(type='face_scale_code',ID=r['ID'],variable=h,value=v))
for s in new:
    h=[c.value for c in s[1]]
    if len(h)<2 or not isinstance(h[1],str):continue
    if h[1].startswith('p_anx'):n=20;rev={1,2,5,8,10,11,15,16,19,20};v=re.sub(r'_1$','',h[1])
    elif h[1].startswith('p_unc'):n=22;rev={5,9,12,13,14,16,18,19,20,22};v=re.sub(r'_?01$','',h[1])
    elif h[1]=='c_beh_change01':n=11;rev=set();v='c_beh_change'
    else:continue
    seen=[];valid=0
    for row in range(2,s.max_row+1):
        i=s.cell(row,1).value
        if not isinstance(i,str) or not re.fullmatch(r'[CE]\d{2}',i):continue
        seen.append(i);values=[s.cell(row,j+1).value for j in range(1,n+1)]
        bad=False
        for j,x in enumerate(values,1):
            if not isinstance(x,(int,float)) or x!=int(x) or not 1<=x<=(5 if n==11 else 4):
                issues.append(dict(type='item_range_missing',sheet=s.title,ID=i,cell=s.cell(row,j+1).coordinate,value=x));bad=True
        if bad:continue
        score=sum(5-x if j in rev else x for j,x in enumerate(values,1))/(11 if n==11 else 1)
        valid+=1;cached=cache[s.title].cell(row,n+2).value
        for kind,target,tol in [('item_cache',cached,1e-8),('Rawdata_total',byid.get(i,{}).get(v),.00501 if n==11 else 1e-8)]:
            if not isinstance(target,(int,float)) or abs(score-target)>tol:issues.append(dict(type=kind,sheet=s.title,ID=i,variable=v,calculated=score,stored=target))
    summaries.append(dict(sheet=s.title,variable=v,N=len(seen),valid=valid,items=n,reverse=sorted(rev),missing_ID=sorted(set(ids)-set(seen)),extra_ID=sorted(set(seen)-set(ids)),duplicates=[i for i,c in collections.Counter(seen).items() if c>1]))
result=dict(source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),N=len(ids),groups=dict(collections.Counter(r['group'] for r in records)),duplicate_ID=[i for i,c in collections.Counter(ids).items() if c>1],sheets_added=list(set(new.sheetnames)-set(old.sheetnames)),sheets_removed=list(set(old.sheetnames)-set(new.sheetnames)),changes=changes,item_checks=summaries,issues=issues)
(out/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2,default=str))
