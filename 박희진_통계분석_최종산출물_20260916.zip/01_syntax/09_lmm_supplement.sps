﻿* Supplementary MMRM with common unstructured covariance; not a cure for group heteroscedasticity.
OUTPUT NEW.
GET FILE='C:/projects/박희진/02_output/validated_analysis.sav'.
FILTER OFF.
WEIGHT OFF.
SPLIT FILE OFF.
VARSTOCASES /MAKE outcome FROM c_anx_pre c_anx_post1 c_anx_post2 /INDEX=time /KEEP=ID group /NULL=KEEP.
TITLE 'c_anx: UN covariance MMRM, REML, Satterthwaite'.
MIXED outcome BY group time /CRITERIA=DFMETHOD(SATTERTHWAITE) /FIXED=group time group*time | SSTYPE(3) /METHOD=REML /REPEATED=time | SUBJECT(ID) COVTYPE(UN) /PRINT=SOLUTION TESTCOV /EMMEANS=TABLES(group*time).
GET FILE='C:/projects/박희진/02_output/validated_analysis.sav'.
FILTER OFF.
WEIGHT OFF.
SPLIT FILE OFF.
VARSTOCASES /MAKE outcome FROM b_anx_pre b_anx_post1 b_anx_post2 /INDEX=time /KEEP=ID group /NULL=KEEP.
TITLE 'b_anx: UN covariance MMRM, REML, Satterthwaite'.
MIXED outcome BY group time /CRITERIA=DFMETHOD(SATTERTHWAITE) /FIXED=group time group*time | SSTYPE(3) /METHOD=REML /REPEATED=time | SUBJECT(ID) COVTYPE(UN) /PRINT=SOLUTION TESTCOV /EMMEANS=TABLES(group*time).
GET FILE='C:/projects/박희진/02_output/validated_analysis.sav'.
FILTER OFF.
WEIGHT OFF.
SPLIT FILE OFF.
VARSTOCASES /MAKE outcome FROM p_anx_pre p_anx_post1 p_anx_post2 /INDEX=time /KEEP=ID group /NULL=KEEP.
TITLE 'p_anx: UN covariance MMRM, REML, Satterthwaite'.
MIXED outcome BY group time /CRITERIA=DFMETHOD(SATTERTHWAITE) /FIXED=group time group*time | SSTYPE(3) /METHOD=REML /REPEATED=time | SUBJECT(ID) COVTYPE(UN) /PRINT=SOLUTION TESTCOV /EMMEANS=TABLES(group*time).
GET FILE='C:/projects/박희진/02_output/validated_analysis.sav'.
FILTER OFF.
WEIGHT OFF.
SPLIT FILE OFF.
VARSTOCASES /MAKE outcome FROM p_unc_pre p_unc_post1 p_unc_post2 /INDEX=time /KEEP=ID group /NULL=KEEP.
TITLE 'p_unc: UN covariance MMRM, REML, Satterthwaite'.
MIXED outcome BY group time /CRITERIA=DFMETHOD(SATTERTHWAITE) /FIXED=group time group*time | SSTYPE(3) /METHOD=REML /REPEATED=time | SUBJECT(ID) COVTYPE(UN) /PRINT=SOLUTION TESTCOV /EMMEANS=TABLES(group*time).
OUTPUT SAVE OUTFILE='C:/projects/박희진/02_output/04_lmm.spv'.
OUTPUT EXPORT /CONTENTS EXPORT=ALL /HTML DOCUMENTFILE='C:/projects/박희진/02_output/lmm_viewer.html'.