* 기존 SPV를 SPSS 출력 문서로 열고 읽기용 HTML로 내보낸다. 원본을 저장하지 않는다.
OUTPUT OPEN FILE='C:/projects/박희진/00_original/통계 출력결과.spv'.
OUTPUT EXPORT /CONTENTS EXPORT=ALL /HTML DOCUMENTFILE='C:/projects/박희진/02_output/existing_viewer.html'.
