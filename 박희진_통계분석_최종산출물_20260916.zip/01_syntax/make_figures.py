from analysis_core import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
font_manager.fontManager.addfont('C:/Windows/Fonts/malgun.ttf')
plt.rcParams.update({'font.family':'Malgun Gothic','axes.unicode_minus':False,'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
d=read_new();F=O/'figures';F.mkdir(exist_ok=True)
colors=['#506B85','#D66A36'];times=['사전','사후1','사후2'];groups=['대조군','실험군']
for stem in STEMS:
    fig,axs=plt.subplots(2,3,figsize=(13,7),layout='constrained')
    for j,t in enumerate(['pre','post1','post2']):
        vals=[d.loc[d.group==g,stem+'_'+t].to_numpy(float) for g in [0,1]]
        bp=axs[0,j].boxplot(vals,patch_artist=True,tick_labels=groups)
        for box,col in zip(bp['boxes'],colors):box.set_facecolor(col);box.set_alpha(.4)
        for g in [0,1]:
            axs[0,j].scatter(np.full(len(vals[g]),g+1)+np.linspace(-.09,.09,len(vals[g])),vals[g],s=12,c=colors[g],alpha=.65)
            osm,osr=st.probplot(vals[g],fit=False);axs[1,j].scatter(osm,osr,s=17,color=colors[g],label=groups[g])
            fit=st.linregress(osm,osr);axs[1,j].plot(osm,fit.intercept+fit.slope*np.array(osm),c=colors[g],alpha=.5)
        axs[0,j].set_title(times[j]);axs[0,j].set_ylabel('점수');axs[1,j].set_xlabel('이론적 정규 분위수');axs[1,j].set_ylabel('관측 점수')
    axs[1,2].legend();fig.suptitle(LABELS[stem]+' — 전체 61쌍의 분포와 Q–Q 진단',fontsize=14)
    fig.savefig(F/(stem+'_distribution.png'),dpi=160);plt.close(fig)
    fig,axs=plt.subplots(2,3,figsize=(13,7),layout='constrained')
    for j,t in enumerate(['post1','post2']):
        a,points,fit=ancova(d,stem,t);pts=pd.DataFrame(points)
        for group in [0,1]:
            q=d[d.group==group];x=q[stem+'_pre'];y=q[stem+'_'+t];axs[j,0].scatter(x,y,c=colors[group],s=22,label=groups[group]);slope,intercept,*_=st.linregress(x,y);xx=np.linspace(x.min(),x.max(),60);axs[j,0].plot(xx,intercept+slope*xx,c=colors[group])
            pp=pts[pts.group==group];axs[j,1].scatter(pp.predicted,pp.residual,c=colors[group],s=22)
        axs[j,0].set(xlabel='사전점수',ylabel=times[j+1]+' 점수',title='집단별 회귀선');axs[j,0].legend()
        axs[j,1].axhline(0,c='gray',lw=1);axs[j,1].set(xlabel='공통기울기 예측값',ylabel='잔차',title='잔차–예측값')
        st.probplot(fit.resid,plot=axs[j,2]);axs[j,2].set(title='공통기울기 잔차 Q–Q',xlabel='이론적 분위수',ylabel='잔차')
    fig.suptitle(LABELS[stem]+' — ANCOVA 진단 (삭제 없음)',fontsize=14);fig.savefig(F/(stem+'_ancova_diagnostics.png'),dpi=160);plt.close(fig)
fig,axs=plt.subplots(2,2,figsize=(11,7),layout='constrained')
for ax,stem in zip(axs.flat,STEMS):
    for group in [0,1]:
        v=d.loc[d.group==group,[stem+'_'+t for t in ['pre','post1','post2']]].to_numpy(float);se=v.std(axis=0,ddof=1)/np.sqrt(len(v));ax.errorbar(np.arange(3)+(.035 if group else -.035),v.mean(axis=0),yerr=st.t.ppf(.975,len(v)-1)*se,marker='o',capsize=3,c=colors[group],label=groups[group])
    ax.set_xticks(range(3),times);ax.set_title(LABELS[stem]);ax.set_ylabel('평균 및 95% CI');ax.legend()
fig.suptitle('수정자료: 대조군 30쌍 · 실험군 31쌍',fontsize=14);fig.savefig(F/'outcome_trajectories.png',dpi=180);plt.close(fig)
print('9 figures saved')
