"""Reuse the first revision audit with distinct input, baseline, and output paths."""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
code=(R/'01_syntax/01_check_revision.py').read_text(encoding='utf-8')
code=code.replace('E3E947E2-411D-4DBC-8F38-88BE2545F622','95DDE2D0-3EEE-440B-BBCD-D05CCB985480')
code=code.replace("out=R/'02_output/revision_20260916'", "out=R/'02_output/revision2_20260916'")
code=code.replace("next((R/'00_original').glob('*.xlsx'))", "R/'02_output/revision_20260916/received_RAW_DATA.xlsx'")
exec(compile(code,str(R/'01_syntax/01_check_revision.py'),'exec'))
highlights=[]
for change in changes:
    c=new[change['sheet']][change['cell']]
    highlights.append(dict(sheet=change['sheet'],cell=c.coordinate,fill_type=c.fill.patternType,color_type=c.fill.fgColor.type,color=str(c.fill.fgColor)))
(out/'changed_cell_fills.json').write_text(json.dumps(highlights,ensure_ascii=False,indent=2),encoding='utf-8')
