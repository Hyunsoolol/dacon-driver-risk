﻿* Supplementary changes; Holm adjustment across two post-time comparisons per outcome is in tables.
COMPUTE c_anx_d1=c_anx_post1-c_anx_pre.
COMPUTE c_anx_d2=c_anx_post2-c_anx_pre.
COMPUTE b_anx_d1=b_anx_post1-b_anx_pre.
COMPUTE b_anx_d2=b_anx_post2-b_anx_pre.
COMPUTE p_anx_d1=p_anx_post1-p_anx_pre.
COMPUTE p_anx_d2=p_anx_post2-p_anx_pre.
COMPUTE p_unc_d1=p_unc_post1-p_unc_pre.
COMPUTE p_unc_d2=p_unc_post2-p_unc_pre.
T-TEST GROUPS=group(0 1) /VARIABLES=c_anx_d1 c_anx_d2 b_anx_d1 b_anx_d2 p_anx_d1 p_anx_d2 p_unc_d1 p_unc_d2 /ES DISPLAY(TRUE) /CRITERIA=CI(.95).