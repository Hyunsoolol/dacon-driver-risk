from pathlib import Path
R=Path(__file__).resolve().parents[1];root=R.as_posix()
lines=['* Supplementary MMRM with common unstructured covariance; not a cure for group heteroscedasticity.','OUTPUT NEW.']
for s in ['c_anx','b_anx','p_anx','p_unc']:
    lines += [f"GET FILE='{root}/02_output/validated_analysis.sav'.",'FILTER OFF.','WEIGHT OFF.','SPLIT FILE OFF.',f'VARSTOCASES /MAKE outcome FROM {s}_pre {s}_post1 {s}_post2 /INDEX=time /KEEP=ID group /NULL=KEEP.',f"TITLE '{s}: UN covariance MMRM, REML, Satterthwaite'.",'MIXED outcome BY group time /CRITERIA=DFMETHOD(SATTERTHWAITE) /FIXED=group time group*time | SSTYPE(3) /METHOD=REML /REPEATED=time | SUBJECT(ID) COVTYPE(UN) /PRINT=SOLUTION TESTCOV /EMMEANS=TABLES(group*time).']
lines += [f"OUTPUT SAVE OUTFILE='{root}/02_output/04_lmm.spv'.",f"OUTPUT EXPORT /CONTENTS EXPORT=ALL /HTML DOCUMENTFILE='{root}/02_output/lmm_viewer.html'."]
(R/'01_syntax/09_lmm_supplement.sps').write_text('\n'.join(lines),encoding='utf-8-sig')
