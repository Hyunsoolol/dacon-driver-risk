﻿* Run from any directory. Full validated cohort.
OUTPUT NEW.
INSERT FILE='C:/projects/박희진/01_syntax/01_data_check.sps'.
INSERT FILE='C:/projects/박희진/01_syntax/03_descriptive.sps'.
INSERT FILE='C:/projects/박희진/01_syntax/04_baseline.sps'.
INSERT FILE='C:/projects/박희진/01_syntax/05_rm_anova.sps'.
INSERT FILE='C:/projects/박희진/01_syntax/06_ancova.sps'.
INSERT FILE='C:/projects/박희진/01_syntax/07_change_scores.sps'.
OUTPUT SAVE OUTFILE='C:/projects/박희진/02_output/02_final_verified.spv'.
OUTPUT EXPORT /CONTENTS EXPORT=ALL /HTML DOCUMENTFILE='C:/projects/박희진/02_output/final_viewer.html'.