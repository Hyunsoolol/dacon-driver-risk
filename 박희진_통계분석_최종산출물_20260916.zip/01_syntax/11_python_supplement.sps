* Reproduce HC3, exhaustive leave-one-out, bootstrap, and independent numeric checks.
* Requires the accompanying Python scripts/packages. Paths refer to this workstation.
* Python supplements are explicitly distinguished from native SPSS procedures.
BEGIN PROGRAM Python3.
import subprocess
python = 'C:/Users/shs70/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
for script in ['analysis_core.py', 'analysis_followup.py']:
    result = subprocess.run([python, 'C:/projects/박희진/01_syntax/'+script], capture_output=True, text=True, encoding='utf-8', errors='replace')
    print(result.stdout)
    if result.returncode:
        raise RuntimeError(result.stderr)
END PROGRAM.
