from pathlib import Path
from html.parser import HTMLParser
import json,re
R=Path(__file__).resolve().parents[1]
class P(HTMLParser):
    def __init__(self):super().__init__();self.parts=[];self.tables=[];self.table=None;self.row=None;self.cell=None
    def handle_starttag(self,tag,attrs):
        if tag=='table':self.table=[]
        if tag=='tr':self.row=[]
        if tag in ['td','th']:self.cell=[]
        if tag in ['p','br','tr','h1','h2','h3']:self.parts.append('\n')
    def handle_endtag(self,tag):
        if tag in ['td','th'] and self.cell is not None:
            if self.row is not None:self.row.append(''.join(self.cell).strip())
            self.cell=None;self.parts.append('\t')
        if tag=='tr' and self.row is not None:
            if self.table is not None:self.table.append(self.row)
            self.row=None
        if tag=='table' and self.table is not None:self.tables.append(self.table);self.table=None
    def handle_data(self,s):
        self.parts.append(s)
        if self.cell is not None:self.cell.append(s)
for f in (R/'02_output').glob('*viewer.html'):
    p=P();p.feed(f.read_text(encoding='utf-8-sig',errors='replace'))
    f.with_suffix('.txt').write_text(''.join(p.parts),encoding='utf-8')
    f.with_suffix('.json').write_text(json.dumps(p.tables,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f.name,'tables',len(p.tables))
