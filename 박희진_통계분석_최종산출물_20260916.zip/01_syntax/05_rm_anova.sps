﻿* c_anx: primary is group by time; GG and HF appear in the output.
GLM c_anx_pre c_anx_post1 c_anx_post2 BY group
 /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3)
 /PRINT=DESCRIPTIVE ETASQ HOMOGENEITY
 /EMMEANS=TABLES(group*time) COMPARE(group) ADJ(BONFERRONI)
 /EMMEANS=TABLES(group*time) COMPARE(time) ADJ(BONFERRONI)
 /WSDESIGN=time /DESIGN=group.

* b_anx: primary is group by time; GG and HF appear in the output.
GLM b_anx_pre b_anx_post1 b_anx_post2 BY group
 /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3)
 /PRINT=DESCRIPTIVE ETASQ HOMOGENEITY
 /EMMEANS=TABLES(group*time) COMPARE(group) ADJ(BONFERRONI)
 /EMMEANS=TABLES(group*time) COMPARE(time) ADJ(BONFERRONI)
 /WSDESIGN=time /DESIGN=group.

* p_anx: primary is group by time; GG and HF appear in the output.
GLM p_anx_pre p_anx_post1 p_anx_post2 BY group
 /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3)
 /PRINT=DESCRIPTIVE ETASQ HOMOGENEITY
 /EMMEANS=TABLES(group*time) COMPARE(group) ADJ(BONFERRONI)
 /EMMEANS=TABLES(group*time) COMPARE(time) ADJ(BONFERRONI)
 /WSDESIGN=time /DESIGN=group.

* p_unc: primary is group by time; GG and HF appear in the output.
GLM p_unc_pre p_unc_post1 p_unc_post2 BY group
 /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3)
 /PRINT=DESCRIPTIVE ETASQ HOMOGENEITY
 /EMMEANS=TABLES(group*time) COMPARE(group) ADJ(BONFERRONI)
 /EMMEANS=TABLES(group*time) COMPARE(time) ADJ(BONFERRONI)
 /WSDESIGN=time /DESIGN=group.
