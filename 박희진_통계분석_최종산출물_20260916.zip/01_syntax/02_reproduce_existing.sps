﻿* Reproduce every analyzable command found in the existing SPV Notes.
OUTPUT NEW.
GET FILE='C:/projects/박희진/00_original/통계돌리는중.sav'.
WEIGHT OFF.
SPLIT FILE OFF.
FILTER OFF.
* Original note 00000000001_lightNotesData.bin.
FILTER OFF.
FREQUENCIES VARIABLES=sex relation p_age p_edu p_income
  /ORDER=ANALYSIS.

* Original note 00000000011_lightNotesData.bin.
FILTER OFF.
DESCRIPTIVES VARIABLES=age
  /STATISTICS=MEAN STDDEV MIN MAX.

* Original note 00000000021_lightNotesData.bin.
FILTER OFF.
T-TEST GROUPS=group(0 1)
  /MISSING=ANALYSIS
  /VARIABLES=age
  /ES DISPLAY(TRUE)
  /HOMOGENEITY DISPLAY(FALSE)
  /CRITERIA=CI(.95).

* Original note 00000000031_lightNotesData.bin.
FILTER OFF.
CROSSTABS
  /TABLES=group BY sex
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ
  /CELLS=COUNT ROW
  /COUNT ROUND CELL
  /METHOD=EXACT TIMER(5).

* Original note 00000000041_lightNotesData.bin.
FILTER OFF.
CROSSTABS
  /TABLES=group BY relation
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ
  /CELLS=COUNT ROW
  /COUNT ROUND CELL
  /METHOD=EXACT TIMER(5).

* Original note 00000000051_lightNotesData.bin.
FILTER OFF.
CROSSTABS
  /TABLES=group BY p_age
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ
  /CELLS=COUNT ROW
  /COUNT ROUND CELL
  /METHOD=EXACT TIMER(5).

* Original note 00000000061_lightNotesData.bin.
FILTER OFF.
CROSSTABS
  /TABLES=group BY p_edu
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ
  /CELLS=COUNT ROW
  /COUNT ROUND CELL
  /METHOD=EXACT TIMER(5).

* Original note 00000000071_lightNotesData.bin.
FILTER OFF.
CROSSTABS
  /TABLES=group BY p_income
  /FORMAT=AVALUE TABLES
  /STATISTICS=CHISQ
  /CELLS=COUNT ROW
  /COUNT ROUND CELL
  /METHOD=EXACT TIMER(5).

* Original note 00000000081_lightNotesData.bin.
FILTER OFF.
EXAMINE VARIABLES=c_anx_pre b_anx_pre p_anx_pre p_unc_pre BY group
  /PLOT BOXPLOT STEMLEAF NPPLOT
  /COMPARE GROUPS
  /STATISTICS DESCRIPTIVES
  /CINTERVAL 95
  /MISSING LISTWISE
  /NOTOTAL.

* Original note 00000000091_lightNotesData.bin.
FILTER OFF.
T-TEST GROUPS=group(0 1)
  /MISSING=ANALYSIS
  /VARIABLES=p_anx_pre p_unc_pre
  /ES DISPLAY(TRUE)
  /HOMOGENEITY DISPLAY(FALSE)
  /CRITERIA=CI(.95).

* Original note 00000000101_lightNotesData.bin.
FILTER OFF.
ONEWAY p_anx_pre p_unc_pre BY group
  /ES=OVERALL
  /STATISTICS HOMOGENEITY
  /MISSING ANALYSIS
  /CRITERIA=CILEVEL(0.95).

* Original note 00000000111_lightNotesData.bin.
FILTER OFF.
NPAR TESTS
  /M-W= c_anx_pre b_anx_pre BY group(0 1)
  /MISSING ANALYSIS.

* Original note 00000000121_lightNotesData.bin.
FILTER OFF.
EXAMINE VARIABLES=c_anx_pre b_anx_pre p_anx_pre p_unc_pre c_anx_post1 b_anx_post1 p_anx_post1
    p_unc_post1 c_anx_post2 b_anx_post2 p_anx_post2 p_unc_post2 BY group
  /PLOT BOXPLOT STEMLEAF NPPLOT
  /COMPARE GROUPS
  /STATISTICS DESCRIPTIVES
  /CINTERVAL 95
  /MISSING LISTWISE
  /NOTOTAL.

* Original note 00000000131_lightNotesData.bin.
FILTER OFF.
GLM p_anx_pre p_anx_post1 p_anx_post2 BY group
  /WSFACTOR=time 3 Polynomial
  /METHOD=SSTYPE(3)
  /PLOT=PROFILE(time*group) TYPE=LINE ERRORBAR=NO MEANREFERENCE=NO YAXIS=AUTO
  /EMMEANS=TABLES(time) COMPARE ADJ(BONFERRONI)
  /EMMEANS=TABLES(group) COMPARE ADJ(BONFERRONI)
  /EMMEANS=TABLES(group*time)
  /PRINT=DESCRIPTIVE ETASQ HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /WSDESIGN=time
  /DESIGN=group.

* Original note 00000000141_lightNotesData.bin.
FILTER OFF.
GLM p_unc_pre p_unc_post1 p_unc_post2 BY group
  /WSFACTOR=time 3 Polynomial
  /METHOD=SSTYPE(3)
  /PLOT=PROFILE(time*group) TYPE=LINE ERRORBAR=NO MEANREFERENCE=NO YAXIS=AUTO
  /EMMEANS=TABLES(time) COMPARE ADJ(BONFERRONI)
  /EMMEANS=TABLES(group*time)
  /PRINT=DESCRIPTIVE ETASQ HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /WSDESIGN=time
  /DESIGN=group.

* Original note 00000000151_lightNotesData.bin.
FILTER OFF.
COMPUTE repro_filter=(group=0).
FILTER BY repro_filter.
NPAR TESTS
  /FRIEDMAN=c_anx_pre c_anx_post1 c_anx_post2
  /MISSING LISTWISE.

* Original note 00000000161_lightNotesData.bin.
FILTER OFF.
COMPUTE repro_filter=(group=1).
FILTER BY repro_filter.
NPAR TESTS
  /FRIEDMAN=c_anx_pre c_anx_post1 c_anx_post2
  /MISSING LISTWISE.

* Original note 00000000171_lightNotesData.bin.
FILTER OFF.
COMPUTE repro_filter=(group=1).
FILTER BY repro_filter.
NPAR TESTS
  /WILCOXON=c_anx_pre c_anx_pre c_anx_post1 WITH c_anx_post1 c_anx_post2 c_anx_post2 (PAIRED)
  /MISSING ANALYSIS.

* Original note 00000000181_lightNotesData.bin.
FILTER OFF.
COMPUTE repro_filter=(group=0).
FILTER BY repro_filter.
NPAR TESTS
  /WILCOXON=c_anx_pre c_anx_pre c_anx_post1 WITH c_anx_post1 c_anx_post2 c_anx_post2 (PAIRED)
  /MISSING ANALYSIS.

* Original note 00000000191_lightNotesData.bin.
FILTER OFF.
NPAR TESTS
  /M-W= c_anx_pre c_anx_post1 c_anx_post2 BY group(0 1)
  /MISSING ANALYSIS.

* Original note 00000000201_lightNotesData.bin.
FILTER OFF.
GLM c_anx_pre c_anx_post1 c_anx_post2 BY group
  /WSFACTOR=time 3 Polynomial
  /METHOD=SSTYPE(3)
  /PLOT=PROFILE(time*group) TYPE=LINE ERRORBAR=NO MEANREFERENCE=NO YAXIS=AUTO
  /EMMEANS=TABLES(time) COMPARE ADJ(BONFERRONI)
  /EMMEANS=TABLES(group) COMPARE ADJ(BONFERRONI)
  /EMMEANS=TABLES(group*time)
  /PRINT=DESCRIPTIVE ETASQ HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /WSDESIGN=time
  /DESIGN=group.

* Original note 00000000211_lightNotesData.bin.
FILTER OFF.
COMPUTE repro_filter=(group=0).
FILTER BY repro_filter.
NPAR TESTS
  /FRIEDMAN=b_anx_pre b_anx_post1 b_anx_post2
  /MISSING LISTWISE.

* Original note 00000000221_lightNotesData.bin.
FILTER OFF.
COMPUTE repro_filter=(group=1).
FILTER BY repro_filter.
NPAR TESTS
  /FRIEDMAN=b_anx_pre b_anx_post1 b_anx_post2
  /MISSING LISTWISE.

* Original note 00000000231_lightNotesData.bin.
FILTER OFF.
COMPUTE repro_filter=(group=1).
FILTER BY repro_filter.
NPAR TESTS
  /WILCOXON=b_anx_pre b_anx_pre b_anx_post1 WITH b_anx_post1 b_anx_post2 b_anx_post2 (PAIRED)
  /MISSING ANALYSIS.

* Original note 00000000241_lightNotesData.bin.
FILTER OFF.
COMPUTE repro_filter=(group=0).
FILTER BY repro_filter.
NPAR TESTS
  /WILCOXON=b_anx_pre b_anx_pre b_anx_post1 WITH b_anx_post1 b_anx_post2 b_anx_post2 (PAIRED)
  /MISSING ANALYSIS.

* Original note 00000000251_lightNotesData.bin.
FILTER OFF.
NPAR TESTS
  /M-W= b_anx_pre b_anx_post1 b_anx_post2 BY group(0 1)
  /MISSING ANALYSIS.

* Original note 00000000261_lightNotesData.bin.
FILTER OFF.
GLM b_anx_pre b_anx_post1 b_anx_post2 BY group
  /WSFACTOR=time 3 Polynomial
  /METHOD=SSTYPE(3)
  /PLOT=PROFILE(time*group) TYPE=LINE ERRORBAR=NO MEANREFERENCE=NO YAXIS=AUTO
  /EMMEANS=TABLES(time) COMPARE ADJ(BONFERRONI)
  /EMMEANS=TABLES(group) COMPARE ADJ(BONFERRONI)
  /EMMEANS=TABLES(group*time)
  /PRINT=DESCRIPTIVE ETASQ HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /WSDESIGN=time
  /DESIGN=group.

* Original note 00000000271_lightNotesData.bin.
FILTER OFF.
EXAMINE VARIABLES=c_beh_change BY group
  /PLOT BOXPLOT STEMLEAF NPPLOT
  /COMPARE GROUPS
  /STATISTICS DESCRIPTIVES
  /CINTERVAL 95
  /MISSING LISTWISE
  /NOTOTAL.

* Original note 00000000281_lightNotesData.bin.
FILTER OFF.
NPAR TESTS
  /M-W= c_beh_change BY group(0 1)
  /MISSING ANALYSIS.

* Original note 00000000291_lightNotesData.bin.
FILTER OFF.
UNIANOVA c_anx_post1 BY group WITH c_anx_pre
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /EMMEANS=TABLES(group) WITH(c_anx_pre=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE PARAMETER HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=c_anx_pre group.

* Original note 00000000301_lightNotesData.bin.
FILTER OFF.
UNIANOVA c_anx_post1 BY group WITH c_anx_pre
  /METHOD=SSTYPE(3)
  /INTERCEPT=INCLUDE
  /EMMEANS=TABLES(group) WITH(c_anx_pre=MEAN) COMPARE ADJ(LSD)
  /PRINT ETASQ DESCRIPTIVE PARAMETER HOMOGENEITY
  /CRITERIA=ALPHA(.05)
  /DESIGN=group c_anx_pre c_anx_pre*group.
FILTER OFF.
OUTPUT SAVE OUTFILE='C:/projects/박희진/02_output/01_reproduced.spv'.
OUTPUT EXPORT /CONTENTS EXPORT=ALL /HTML DOCUMENTFILE='C:/projects/박희진/02_output/reproduced_viewer.html'.
