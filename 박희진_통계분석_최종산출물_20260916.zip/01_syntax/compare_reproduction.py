from pathlib import Path
import json,collections,re
R=Path(__file__).resolve().parents[1];O=R/'02_output'
a=json.loads((O/'existing_viewer.json').read_text(encoding='utf-8'));b=json.loads((O/'reproduced_viewer.json').read_text(encoding='utf-8'))
def key(t):return json.dumps(t,ensure_ascii=False).replace('(0.0%)','(.0%)')
cb=collections.Counter(key(t) for t in b)
rows=[];unmatched=[]
for n,t in enumerate(a):
    # Notes contain volatile paths/times; compare statistical tables separately.
    st=key(t)
    if '작성된 출력결과' in st:continue
    yes=cb[st]>0
    if yes:cb[st]-=1
    else:unmatched.append({'table_index':n,'table':t})
    rows.append(dict(original_table_index=n,exact_table_match=yes))
(O/'reproduction_table_audit.json').write_text(json.dumps(dict(results=rows,unmatched=unmatched),ensure_ascii=False,indent=2),encoding='utf-8')
print('matched',sum(r['exact_table_match'] for r in rows),'of',len(rows))
for t in unmatched:print(json.dumps(t,ensure_ascii=True))
