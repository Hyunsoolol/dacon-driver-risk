"""Append verified supplementary results and delivery instructions; originals remain untouched."""
from pathlib import Path
import csv,json
R=Path(__file__).resolve().parents[1]
report=R/'04_report/statistical_review.md'
s=report.read_text(encoding='utf-8')
s=s.replace('얼굴척도의 불안 측정 타당성과 PHBQ-AS 3점의 의미(변화 없음)를 확인해야 한다. 3점 이상을 일괄 ‘부정적 변화’로 분류하는 문구는 현재 사용하지 않는다.', '얼굴척도의 불안 측정 타당성은 확인이 필요하다. PHBQ-AS 원 개발논문에서 평균 3점은 변화 없음, 3점 초과는 부정적 변화, 3점 미만은 개선이다. 계획서의 ‘3점 이상’ 분류는 수정해야 하며, 저자명도 Brooke N. Jenkins를 Brook으로 표기하지 않도록 확인한다([Jenkins 등, 2015](https://pmc.ncbi.nlm.nih.gov/articles/PMC4461461/)). 본 분석은 이분화 없이 평균점수를 사용했다.')
extra='''

### 추가 확인: LMM 비교 및 분포 그림

동일한 전체 61명을 대상으로 비구조화 공분산, REML, Satterthwaite 자유도를 적용한 보조 LMM의 Group×Time 결과는 아래와 같다. 보호자 결과의 결론은 동일했다. 이 모형이 집단별 이분산이나 바닥효과까지 해결하는 것은 아니므로 주 분석의 자동 대체 근거로 삼지 않는다.

|결과변수|F(2,59)|p|
|---|---:|---:|
|아동 주관적 불안|4.848|.011|
|아동 행동불안|4.706|.013|
|보호자 불안|1.372|.262|
|보호자 불확실성|0.785|.461|

![집단별 결과변수의 시간 경과](../02_output/figures/outcome_trajectories.png)

집단×시점 boxplot/Q-Q plot 및 ANCOVA 산점도·잔차 그림은 `02_output/figures`에 있다. 조건부 ANCOVA의 4개 기준값에서 보정차이와 95% CI는 SPSS 출력과 독립 계산이 반올림 범위에서 일치함을 확인했다.
'''
if '### 추가 확인: LMM 비교' not in s:s+=extra
report.write_text(s,encoding='utf-8')
p=R/'03_tables/paper_tables.md';s=p.read_text(encoding='utf-8')
if '### 추가 확인: LMM 비교' not in s:s+=extra.split('![집단별')[0]
p.write_text(s,encoding='utf-8')
(R/'04_report/README.md').write_text('''# 최종 분석 산출물 안내 — 2026-09-16

최신 재수정 Excel을 사용한 전체 61명 분석이다. 원본 7개 파일은 수정하지 않았으며 SHA256 일치를 확인했다. 기존 SPSS의 비교 가능한 결과표 145개가 모두 재현되었고, 최종 SPSS와 독립 계산·자료·원본 보존 검증 32건이 통과했다.

## 먼저 읽을 문서

- [분석 검증 보고서](statistical_review.md): 연구설계, 분석 적절성 판정, 가정·영향점·민감도 및 한계
- [의뢰자 설명용 요약](client_summary.md)
- [논문용 결과표](../03_tables/paper_tables.md)
- [기존 결과·재현·수정 결과 비교](../03_tables/reproduction_comparison.md)
- [논문 Methods 문장](paper_methods.md), [Results 문장](paper_results.md)

모집명부의 중복·누락·일자, 실제 사전측정과 교육의 선후, 척도 원 채점표 확인은 연구자에게 남은 확인사항이다. 해당 사실을 수치 분석으로 확정하지 않았다.

## 최종 SPSS 출력

- `02_output/01_reproduced.spv`: 기존 분석 재현
- **`02_output/02_final_verified.spv`: 최종 전체자료 분석 및 가정 진단**
- `02_output/03_sensitivity.spv`: 객관적 영향점 기준에 따른 보조 민감도
- `02_output/04_lmm.spv`: LMM 보조 비교
- `02_output/05_conditional.spv`: 보호자 불안 사후2 상호작용 모형의 조건부 효과

`02_final_analysis.spv`는 진단 명령 수정 이전 중간 출력이므로 최종 인용에 사용하지 않는다. 최종 수치 CSV는 `03_tables`, 그림은 `02_output/figures`에 있다. HC3·bootstrap 등 Python 보조 결과는 CSV에 별도로 표시했다.

## 재현 순서

1. IBM SPSS Statistics에서 `01_syntax/02_reproduce_existing.sps`로 기존 결과를 재현한다.
2. `01_syntax/00_run_final.sps`를 실행한다. 자료 확인→기술통계→baseline→RM-ANOVA→ANCOVA 진단→변화량 순이다.
3. `01_syntax/00_run_sensitivity.sps`, `09_lmm_supplement.sps`, `10_conditional_anxiety.sps`를 실행한다.
4. Python 보조 분석은 `analysis_core.py` → `analysis_followup.py` 순으로 실행한다. `11_python_supplement.sps`는 같은 스크립트를 호출하는 편의 래퍼이며 래퍼 자체는 실행 검증하지 않았다. 실제 수치는 Python 스크립트를 직접 실행하여 검증했다.
5. 결과 HTML을 `parse_viewer.py`로 파싱한 뒤 `final_qa.py`로 수치를 대조한다. `make_figures.py`, `write_reports.py`, `finish_delivery.py` 순으로 그림·문서를 생성한다.

경로는 현재 PC의 `C:/projects/박희진` 및 설치 Python/SPSS에 맞춰져 있다. 다른 PC에서는 경로와 패키지 설치를 조정해야 한다. Python 패키지는 `02_output/python_packages`에서 로드한다. 출력 재실행 전에는 저장 대상과 같은 SPV 파일을 Viewer에서 닫아 파일 잠금을 해제한다. 입력 수정본은 `02_output/revision2_20260916/received_RAW_DATA.xlsx`이며 `00_original`은 쓰기 대상이 아니다.

전체자료가 주 분석이며 영향점 삭제 결과는 진단 목적이다. 삭제로 유의성을 만드는 선택을 하지 않았다. 비무작위·비동시 설계이므로 보정 결과를 곧바로 인과효과로 해석하지 않는다.
''',encoding='utf-8')
for path in list((R/'04_report').glob('*.md'))+list((R/'03_tables').glob('*.md')):
    text=path.read_text(encoding='utf-8')
    if 'p=<' in text:path.write_text(text.replace('p=<','p<'),encoding='utf-8')
print('Delivery documents completed')
