* Full-cohort caregiver anxiety post2: retain the baseline interaction.
* Levels are descriptive reference points within observed common support.
OUTPUT NEW.
GET FILE='C:/projects/박희진/02_output/validated_analysis.sav'.
FILTER OFF.
WEIGHT OFF.
SPLIT FILE OFF.
UNIANOVA p_anx_post2 BY group WITH p_anx_pre
 /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ
 /EMMEANS=TABLES(group) WITH(p_anx_pre=30) COMPARE(group) ADJ(LSD)
 /EMMEANS=TABLES(group) WITH(p_anx_pre=40) COMPARE(group) ADJ(LSD)
 /EMMEANS=TABLES(group) WITH(p_anx_pre=50) COMPARE(group) ADJ(LSD)
 /EMMEANS=TABLES(group) WITH(p_anx_pre=42.19672131147541) COMPARE(group) ADJ(LSD)
 /DESIGN=group p_anx_pre group*p_anx_pre.
OUTPUT SAVE OUTFILE='C:/projects/박희진/02_output/05_conditional.spv'.
OUTPUT EXPORT /CONTENTS EXPORT=ALL /HTML DOCUMENTFILE='C:/projects/박희진/02_output/conditional_viewer.html'.
