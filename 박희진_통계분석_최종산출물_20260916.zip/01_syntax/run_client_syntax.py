from pathlib import Path
import sys,SpssClient
p=Path(sys.argv[1]).resolve()
SpssClient.StartClient()
try:
    SpssClient.RunSyntax(p.read_text(encoding='utf-8-sig'))
    print('SPSS Client RunSyntax completed',p.name)
finally:SpssClient.StopClient()
