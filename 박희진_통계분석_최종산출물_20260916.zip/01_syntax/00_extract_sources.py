"""Read-only source extraction; original files are never written."""
from pathlib import Path
import sys, hashlib, json, struct, zlib, zipfile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'02_output/python_packages'))
import olefile
from pypdf import PdfReader
OUT=ROOT/'02_output/source_extract'
OUT.mkdir(parents=True,exist_ok=True)
manifest=[]
for p in (ROOT/'00_original').iterdir():
    manifest.append(dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    if p.suffix=='.hwp':
        o=olefile.OleFileIO(str(p)); header=o.openstream('FileHeader').read()
        compressed=struct.unpack_from('<I',header,36)[0]&1
        paragraphs=[]
        for stream in sorted(o.listdir()):
            if stream[0]=='BodyText' and stream[-1].startswith('Section'):
                b=o.openstream(stream).read()
                if compressed:b=zlib.decompress(b,-15)
                pos=0
                while pos+4<=len(b):
                    v=struct.unpack_from('<I',b,pos)[0];pos+=4
                    tag=v&1023;size=v>>20
                    if size==4095:size=struct.unpack_from('<I',b,pos)[0];pos+=4
                    data=b[pos:pos+size];pos+=size
                    if tag==67:
                        units=list(struct.unpack('<'+'H'*(len(data)//2),data[:len(data)//2*2])); clean=[];i=0
                        while i<len(units):
                            u=units[i]
                            if u in (1,2,3,4,5,6,7,8,9,11,12,14,15,16,17,18,19,20,21,22,23):
                                if u==9:clean.append(9)
                                i+=8
                            else:
                                if u>=32 or u in (10,13):clean.append(u)
                                i+=1
                        paragraphs.append(struct.pack('<'+'H'*len(clean),*clean).decode('utf-16le','replace'))
        (OUT/(p.stem+'.txt')).write_text('\n'.join(paragraphs),encoding='utf-8')
    elif p.suffix=='.pdf':
        r=PdfReader(p)
        (OUT/(p.stem+'.txt')).write_text('\n'.join(f'\n--- PAGE {i+1} ---\n'+(page.extract_text() or '') for i,page in enumerate(r.pages)),encoding='utf-8')
    elif p.suffix=='.spv':
        with zipfile.ZipFile(p) as z:
            (OUT/'spv_inventory.txt').write_text('\n'.join(z.namelist()),encoding='utf-8')
            for name in z.namelist():
                if name.endswith('.xml'):(OUT/Path(name).name).write_bytes(z.read(name))
(OUT/'original_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('Source extraction complete')
