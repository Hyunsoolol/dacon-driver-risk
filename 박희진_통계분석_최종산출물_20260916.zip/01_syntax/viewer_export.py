from pathlib import Path
import SpssClient
R=Path(__file__).resolve().parents[1]
SpssClient.StartClient()
try:
    doc=SpssClient.OpenOutputDoc(str(next((R/'00_original').glob('*.spv'))))
    doc.ExportDocument(SpssClient.SpssExportSubset.SpssAll,str(R/'02_output/existing_viewer.html'),SpssClient.DocExportFormat.SpssFormatHtml)
    print('Viewer export completed')
finally:SpssClient.StopClient()
