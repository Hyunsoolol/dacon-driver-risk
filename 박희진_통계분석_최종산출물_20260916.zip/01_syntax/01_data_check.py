from pathlib import Path
import sys,json,re,collections,xml.etree.ElementTree as ET,zipfile,html
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'02_output/python_packages'))
import pandas as pd,numpy as np,openpyxl,pyreadstat
O=R/'02_output';S=O/'source_extract'
d,m=pyreadstat.read_sav(str(next((R/'00_original').glob('*.sav'))));d=d.set_index('ID')
w=openpyxl.load_workbook(next((R/'00_original').glob('*.xlsx')),data_only=False)
wc=openpyxl.load_workbook(next((R/'00_original').glob('*.xlsx')),data_only=True)
raw=list(wc['Rawdata'].values);e=pd.DataFrame(raw[1:],columns=raw[0]).dropna(how='all').set_index('ID')
issues=[]
common=d.index.intersection(e.index)
for v in e.columns:
    for i in common:
        a,b=d.loc[i,v],e.loc[i,v]
        if pd.isna(a) and pd.isna(b):continue
        if not np.isclose(a,b,equal_nan=True):issues.append(dict(type='Excel-SAV',ID=i,variable=v,sav=a,excel=b))
checks={'sav_N':len(d),'excel_N':len(e),'sav_group_N':d.groupby('group').size().to_dict(),'excel_group_N':e.groupby('group').size().to_dict(),'sav_duplicate_ID':d.index[d.index.duplicated()].tolist(),'excel_duplicate_ID':e.index[e.index.duplicated()].tolist(),'Excel_only_ID':e.index.difference(d.index).tolist(),'SAV_only_ID':d.index.difference(e.index).tolist(),'sav_missing':d.isna().sum().to_dict(),'excel_missing':e.isna().sum().to_dict(),'filter_values':d['filter_$'].value_counts().to_dict(),'variable_labels_absent':[v for v in m.column_names if not m.column_names_to_labels[v]],'user_missing':m.missing_ranges,'item_checks':[]}
ranges={'age':(4,6),'group':(0,1),'sex':(1,2),'relation':(1,5),'p_age':(1,4),'p_edu':(1,3),'p_income':(1,4),'c_beh_change':(1,5)}
for v in d.columns:
    for stem,bounds in [('c_anx',(0,10)),('b_anx',(5,22)),('p_anx',(20,80)),('p_unc',(22,88))]:
        if v.startswith(stem):ranges[v]=bounds
for v,(lo,hi) in ranges.items():
    for i in d.index[(d[v]<lo)|(d[v]>hi)]:issues.append(dict(type='range',ID=i,variable=v,value=d.loc[i,v]))
scores=[]
for s in w:
    head=[c.value for c in s[1]]
    if len(head)<2 or not isinstance(head[1],str):continue
    if head[1].startswith('p_anx'): count=20;rev={1,2,5,8,10,11,15,16,19,20};v=re.sub(r'_1$','',head[1])
    elif head[1].startswith('p_unc'):count=22;rev={5,9,12,13,14,16,18,19,20,22};v=re.sub(r'_?01$','',head[1])
    elif head[1]=='c_beh_change01':count=11;rev=set();v='c_beh_change'
    else:continue
    ids=[];invalid=[];missing=[];mismatch=[];formula_types=collections.Counter()
    for row in range(2,s.max_row+1):
        i=s.cell(row,1).value
        if not isinstance(i,str) or not re.fullmatch('[CE]\\d{2}',i):continue
        ids.append(i);values=[s.cell(row,j+1).value for j in range(1,count+1)]
        if any(x is None for x in values):missing.append(i);continue
        if any(not isinstance(x,(int,float)) or x<1 or x>(5 if count==11 else 4) for x in values):invalid.append(i);continue
        score=sum((5-x if j in rev else x) for j,x in enumerate(values,1))
        if count==11:score/=11
        formula=s.cell(row,count+2).value
        if isinstance(formula,str):formula_types[re.sub(r'\d+','@',formula)]+=1
        cached=wc[s.title].cell(row,count+2).value
        for source,target in [('Rawdata',e),('SAV',d)]:
            if i in target.index:
                val=target.loc[i,v]
                tol=.00501 if count==11 else 1e-9
                if not np.isclose(score,val,atol=tol):mismatch.append((i,source,score,val))
        if cached is not None and isinstance(cached,(int,float)) and not np.isclose(score,cached):issues.append(dict(type='cached_formula',ID=i,variable=v,calc=score,cached=cached))
        scores.append(dict(ID=i,variable=v,calculated=score))
    checks['item_checks'].append(dict(sheet=s.title,variable=v,items=count,reverse=sorted(rev),N=len(ids),duplicates=[i for i,n in collections.Counter(ids).items() if n>1],invalid=invalid,missing=missing,mismatch=mismatch,formula_templates=dict(formula_types)))
    for i,source,score,val in mismatch:issues.append(dict(type='item_total',ID=i,variable=v,source=source,calculated=score,stored=val))
roster=[]
for row in w.worksheets[0]:
    i=row[0].value
    if i is not None:
        roster.append(dict(row=row[0].row,ID=i,dates=[row[j].value for j in (5,6,7)],status=row[8].value))
checks['roster_deidentified']=roster
checks['discrepancies']=issues
(O/'data_integrity.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
pd.DataFrame(issues).to_csv(O/'data_discrepancies.csv',index=False,encoding='utf-8-sig')
pd.DataFrame(scores).to_csv(O/'item_scores_recalculated.csv',index=False,encoding='utf-8-sig')
print(json.dumps({k:v for k,v in checks.items() if k not in ['roster_deidentified','item_checks']},ensure_ascii=False,indent=2))
print('ITEM CHECKS',json.dumps(checks['item_checks'],ensure_ascii=False,indent=2))
# Read XML text and note payloads to preserve the original analysis commands.
logs=[]
with zipfile.ZipFile(next((R/'00_original').glob('*.spv'))) as z:
    for name in z.namelist():
        if name.endswith('heading.xml'):
            root=ET.fromstring(z.read(name));texts=[]
            for el in root.iter():
                if el.tag.endswith('html') and el.text:texts.append(html.unescape(re.sub('<[^>]+>',' ',el.text)))
            logs.append('\n### '+name+'\n'+'\n'.join(texts))
        elif 'NotesData' in name:
            # String extraction provides commands/provenance only, not numeric pivot table values.
            b=z.read(name)
            strings=re.findall(rb'[\x20-\x7e\x80-\xff]{10,}',b)
            logs.append('\n### '+name+'\n'+'\n'.join(t.decode('utf-8','replace') for t in strings))
(S/'spv_command_log.txt').write_text('\n'.join(logs),encoding='utf-8')
