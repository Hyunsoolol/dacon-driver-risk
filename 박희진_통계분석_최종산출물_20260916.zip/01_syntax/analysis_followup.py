from analysis_core import *
d=read_new()
# Interaction model is the appropriate description for caregiver anxiety post2.
x=d.p_anx_pre.to_numpy(float);g=d.group.to_numpy(float);y=d.p_anx_post2.to_numpy(float)
X=np.column_stack([np.ones(len(d)),g,x-x.mean(),g*(x-x.mean())]);f=sm.OLS(y,X).fit();hc=f.get_robustcov_results(cov_type='HC3',use_t=True)
cond=[]
for level in [30,40,50,float(x.mean())]:
    c=np.array([0,1,0,level-x.mean()]);a=f.t_test(c);h=hc.t_test(c)
    cond.append(dict(baseline=level,difference=float(a.effect[0]),SE=float(a.sd[0,0]),CI_low=float(a.conf_int()[0,0]),CI_high=float(a.conf_int()[0,1]),p=float(a.pvalue),HC3_low=float(h.conf_int()[0,0]),HC3_high=float(h.conf_int()[0,1]),HC3_p=float(h.pvalue),slope_control=f.params[2],slope_experimental=f.params[2]+f.params[3],interaction_p=f.pvalues[3],interaction_HC3_p=hc.pvalues[3]))
dump('14_anxiety_post2_conditional',cond)
ip=[];inf=f.get_influence()
for j,i in enumerate(d.ID):
    q=d[d.ID!=i];xx=q.p_anx_pre.to_numpy(float)-x.mean();gg=q.group.to_numpy(float)
    ff=sm.OLS(q.p_anx_post2.to_numpy(float),np.column_stack([np.ones(len(q)),gg,xx,gg*xx])).fit()
    ip.append(dict(ID=i,Cook=inf.cooks_distance[0][j],leverage=inf.hat_matrix_diag[j],studentized=inf.resid_studentized_external[j],DFBETA_group=inf.dfbetas[j,1],DFBETA_interaction=inf.dfbetas[j,3],LOO_interaction_p=ff.pvalues[3],LOO_interaction_slope=ff.params[3]))
dump('15_interaction_model_influence',ip)
# Subject-vector bootstrap under a centered equal-change null, preserving each group's covariance.
# This is a supportive, nonrandomization bootstrap, not a causal randomization test.
rng=np.random.default_rng(20260916);rob=[];B=9999
for stem in STEMS:
    vals=d[[stem+'_pre',stem+'_post1',stem+'_post2']].to_numpy(float)
    ch=vals[:,1:]-vals[:,[0]];a=ch[g==1];b=ch[g==0];delta=a.mean(0)-b.mean(0)
    V=np.cov(a,rowvar=False)/len(a)+np.cov(b,rowvar=False)/len(b);W=float(delta@np.linalg.solve(V,delta))
    ca=a-a.mean(0);cb=b-b.mean(0);exceed=0
    for _ in range(B):
        aa=ca[rng.integers(0,len(a),len(a))];bb=cb[rng.integers(0,len(b),len(b))];dd=aa.mean(0)-bb.mean(0)
        vv=np.cov(aa,rowvar=False)/len(a)+np.cov(bb,rowvar=False)/len(b)
        exceed+=float(dd@np.linalg.solve(vv,dd))>=W
    rob.append(dict(outcome=stem,Wald=W,df=2,asymptotic_p=st.chi2.sf(W,2),bootstrap_p=(exceed+1)/(B+1),B=B,seed=20260916))
dump('16_robust_change_vector',rob)
print(pd.DataFrame(cond).to_string(index=False));print(pd.DataFrame(rob).to_string(index=False))
loo=pd.read_csv(T/'13_leave_one_out.csv');sen=pd.read_csv(T/'11_sensitivity_ancova.csv');rs=pd.read_csv(T/'12_sensitivity_rm.csv')
for s in ['p_anx','p_unc']:
    print('SENS',s)
    print(sen[(sen.outcome==s)&sen.scenario.isin(['A_all','B_joint_influence'])][['scenario','time','N','difference','CI_low','CI_high','p','partial_eta2']].to_string(index=False))
    for t in ['post1','post2']:
        q=loo[(loo.outcome==s)&(loo.time==t)];print(t,'LOO diff',q.difference.min(),q.difference.max(),'p',q.p.min(),q.p.max(),'RM',q.RM_GG_p.min(),q.RM_GG_p.max())
    print(rs[(rs.outcome==s)&rs.scenario.isin(['A_all','B_joint_influence'])].to_string(index=False))
# Original-data independent computations, for HWP comparison and correction impact.
old=pd.read_csv(O/'source_extract/sav_values.csv');rows=[]
for stem in STEMS:
    r,sp=rm(old,stem)
    for z in r:rows.append(dict(dataset='original',**z))
dump('17_original_independent_RM',rows)
