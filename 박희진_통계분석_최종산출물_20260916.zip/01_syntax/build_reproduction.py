from pathlib import Path
import re
R=Path(__file__).resolve().parents[1]
text=(R/'02_output/source_extract/spv_command_log.txt').read_text(encoding='utf-8')
commands=[]
for block in text.split('\n### '):
    if 'lightNotesData.bin' not in block.split('\n')[0]:continue
    lines=block.splitlines();clean=[]
    for k,line in enumerate(lines):
        if k+1<len(lines) and line==lines[k+1]+'X':continue
        clean.append(line)
    clean=[('CROSSTABS' if l=='CROSSTABSX' else l) for l in clean]
    start=next((k for k,l in enumerate(clean) if re.match(r'^(FREQUENCIES|DESCRIPTIVES|T-TEST|CROSSTABS|ONEWAY|EXAMINE|NPAR TESTS|GLM |UNIANOVA)',l)),None)
    if start is None:continue
    cmd=[]
    for l in clean[start:]:
        cmd.append(l)
        if l.rstrip().endswith('.'):break
    group= re.search(r'group = ([01]) \(FILTER\)',block)
    prefix='FILTER OFF.\n'
    if group:prefix+=f'COMPUTE repro_filter=(group={group[1]}).\nFILTER BY repro_filter.\n'
    commands.append(f'* Original note {block.splitlines()[0]}.\n'+prefix+'\n'.join(cmd))
header="* Reproduce every analyzable command found in the existing SPV Notes.\nOUTPUT NEW.\nGET FILE='C:/projects/박희진/00_original/통계돌리는중.sav'.\nWEIGHT OFF.\nSPLIT FILE OFF.\nFILTER OFF.\n"
footer="\nFILTER OFF.\nOUTPUT SAVE OUTFILE='C:/projects/박희진/02_output/01_reproduced.spv'.\nOUTPUT EXPORT /CONTENTS EXPORT=ALL /HTML DOCUMENTFILE='C:/projects/박희진/02_output/reproduced_viewer.html'.\n"
(R/'01_syntax/02_reproduce_existing.sps').write_text(header+'\n\n'.join(commands)+footer,encoding='utf-8-sig')
print('\n\n'.join(commands))
