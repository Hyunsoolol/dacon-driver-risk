﻿* Diagnostic deletions, never the primary analysis. All IDs were selected by influence thresholds, not p values.
* p_anx scenario all.
COMPUTE sensitivity_filter=(1).
FILTER BY sensitivity_filter.
GLM p_anx_pre p_anx_post1 p_anx_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_anx_post1 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
UNIANOVA p_anx_post2 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
FILTER OFF.
* p_anx scenario C04.
COMPUTE sensitivity_filter=(ID <> 'C04').
FILTER BY sensitivity_filter.
GLM p_anx_pre p_anx_post1 p_anx_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_anx_post1 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
UNIANOVA p_anx_post2 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
FILTER OFF.
* p_anx scenario C06.
COMPUTE sensitivity_filter=(ID <> 'C06').
FILTER BY sensitivity_filter.
GLM p_anx_pre p_anx_post1 p_anx_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_anx_post1 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
UNIANOVA p_anx_post2 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
FILTER OFF.
* p_anx scenario C11.
COMPUTE sensitivity_filter=(ID <> 'C11').
FILTER BY sensitivity_filter.
GLM p_anx_pre p_anx_post1 p_anx_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_anx_post1 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
UNIANOVA p_anx_post2 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
FILTER OFF.
* p_anx scenario C24.
COMPUTE sensitivity_filter=(ID <> 'C24').
FILTER BY sensitivity_filter.
GLM p_anx_pre p_anx_post1 p_anx_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_anx_post1 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
UNIANOVA p_anx_post2 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
FILTER OFF.
* p_anx scenario E01.
COMPUTE sensitivity_filter=(ID <> 'E01').
FILTER BY sensitivity_filter.
GLM p_anx_pre p_anx_post1 p_anx_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_anx_post1 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
UNIANOVA p_anx_post2 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
FILTER OFF.
* p_anx scenario E07.
COMPUTE sensitivity_filter=(ID <> 'E07').
FILTER BY sensitivity_filter.
GLM p_anx_pre p_anx_post1 p_anx_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_anx_post1 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
UNIANOVA p_anx_post2 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
FILTER OFF.
* p_anx scenario E18.
COMPUTE sensitivity_filter=(ID <> 'E18').
FILTER BY sensitivity_filter.
GLM p_anx_pre p_anx_post1 p_anx_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_anx_post1 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
UNIANOVA p_anx_post2 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
FILTER OFF.
* p_anx scenario E30.
COMPUTE sensitivity_filter=(ID <> 'E30').
FILTER BY sensitivity_filter.
GLM p_anx_pre p_anx_post1 p_anx_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_anx_post1 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
UNIANOVA p_anx_post2 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
FILTER OFF.
* p_anx scenario joint.
COMPUTE sensitivity_filter=(ID <> 'C04' AND ID <> 'C06' AND ID <> 'C11' AND ID <> 'C24' AND ID <> 'E01' AND ID <> 'E07' AND ID <> 'E18' AND ID <> 'E30').
FILTER BY sensitivity_filter.
GLM p_anx_pre p_anx_post1 p_anx_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_anx_post1 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
UNIANOVA p_anx_post2 BY group WITH p_anx_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_anx_pre=MEAN) COMPARE(group) /DESIGN=group p_anx_pre.
FILTER OFF.
* p_unc scenario all.
COMPUTE sensitivity_filter=(1).
FILTER BY sensitivity_filter.
GLM p_unc_pre p_unc_post1 p_unc_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_unc_post1 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
UNIANOVA p_unc_post2 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
FILTER OFF.
* p_unc scenario C10.
COMPUTE sensitivity_filter=(ID <> 'C10').
FILTER BY sensitivity_filter.
GLM p_unc_pre p_unc_post1 p_unc_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_unc_post1 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
UNIANOVA p_unc_post2 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
FILTER OFF.
* p_unc scenario C15.
COMPUTE sensitivity_filter=(ID <> 'C15').
FILTER BY sensitivity_filter.
GLM p_unc_pre p_unc_post1 p_unc_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_unc_post1 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
UNIANOVA p_unc_post2 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
FILTER OFF.
* p_unc scenario C22.
COMPUTE sensitivity_filter=(ID <> 'C22').
FILTER BY sensitivity_filter.
GLM p_unc_pre p_unc_post1 p_unc_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_unc_post1 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
UNIANOVA p_unc_post2 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
FILTER OFF.
* p_unc scenario E01.
COMPUTE sensitivity_filter=(ID <> 'E01').
FILTER BY sensitivity_filter.
GLM p_unc_pre p_unc_post1 p_unc_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_unc_post1 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
UNIANOVA p_unc_post2 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
FILTER OFF.
* p_unc scenario E07.
COMPUTE sensitivity_filter=(ID <> 'E07').
FILTER BY sensitivity_filter.
GLM p_unc_pre p_unc_post1 p_unc_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_unc_post1 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
UNIANOVA p_unc_post2 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
FILTER OFF.
* p_unc scenario E12.
COMPUTE sensitivity_filter=(ID <> 'E12').
FILTER BY sensitivity_filter.
GLM p_unc_pre p_unc_post1 p_unc_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_unc_post1 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
UNIANOVA p_unc_post2 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
FILTER OFF.
* p_unc scenario E18.
COMPUTE sensitivity_filter=(ID <> 'E18').
FILTER BY sensitivity_filter.
GLM p_unc_pre p_unc_post1 p_unc_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_unc_post1 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
UNIANOVA p_unc_post2 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
FILTER OFF.
* p_unc scenario E23.
COMPUTE sensitivity_filter=(ID <> 'E23').
FILTER BY sensitivity_filter.
GLM p_unc_pre p_unc_post1 p_unc_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_unc_post1 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
UNIANOVA p_unc_post2 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
FILTER OFF.
* p_unc scenario E26.
COMPUTE sensitivity_filter=(ID <> 'E26').
FILTER BY sensitivity_filter.
GLM p_unc_pre p_unc_post1 p_unc_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_unc_post1 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
UNIANOVA p_unc_post2 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
FILTER OFF.
* p_unc scenario joint.
COMPUTE sensitivity_filter=(ID <> 'C10' AND ID <> 'C15' AND ID <> 'C22' AND ID <> 'E01' AND ID <> 'E07' AND ID <> 'E12' AND ID <> 'E18' AND ID <> 'E23' AND ID <> 'E26').
FILTER BY sensitivity_filter.
GLM p_unc_pre p_unc_post1 p_unc_post2 BY group /WSFACTOR=time 3 Polynomial /METHOD=SSTYPE(3) /PRINT=ETASQ /WSDESIGN=time /DESIGN=group.
UNIANOVA p_unc_post1 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
UNIANOVA p_unc_post2 BY group WITH p_unc_pre /METHOD=SSTYPE(3) /PRINT=PARAMETER ETASQ /EMMEANS=TABLES(group) WITH(p_unc_pre=MEAN) COMPARE(group) /DESIGN=group p_unc_pre.
FILTER OFF.