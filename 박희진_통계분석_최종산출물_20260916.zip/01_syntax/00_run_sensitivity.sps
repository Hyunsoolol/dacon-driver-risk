﻿OUTPUT NEW.
GET FILE='C:/projects/박희진/02_output/validated_analysis.sav'.
INSERT FILE='C:/projects/박희진/01_syntax/08_outlier_sensitivity.sps'.
OUTPUT SAVE OUTFILE='C:/projects/박희진/02_output/03_sensitivity.spv'.
OUTPUT EXPORT /CONTENTS EXPORT=ALL /HTML DOCUMENTFILE='C:/projects/박희진/02_output/sensitivity_viewer.html'.