# 최종 분석 산출물 안내 — 2026-09-16

최신 재수정 Excel을 사용한 전체 61명 분석이다. 원본 7개 파일은 수정하지 않았으며 SHA256 일치를 확인했다. 기존 SPSS의 비교 가능한 결과표 145개가 모두 재현되었고, 최종 SPSS와 독립 계산·자료·원본 보존 검증 32건이 통과했다.

## 먼저 읽을 문서

- [분석 검증 보고서](statistical_review.md): 연구설계, 분석 적절성 판정, 가정·영향점·민감도 및 한계
- [의뢰자 설명용 요약](client_summary.md)
- [논문용 결과표](../03_tables/paper_tables.md)
- [기존 결과·재현·수정 결과 비교](../03_tables/reproduction_comparison.md)
- [논문 Methods 문장](paper_methods.md), [Results 문장](paper_results.md)

모집명부의 중복·누락·일자, 실제 사전측정과 교육의 선후, 척도 원 채점표 확인은 연구자에게 남은 확인사항이다. 해당 사실을 수치 분석으로 확정하지 않았다.

## 최종 SPSS 출력

- `02_output/01_reproduced.spv`: 기존 분석 재현
- **`02_output/02_final_verified.spv`: 최종 전체자료 분석 및 가정 진단**
- `02_output/03_sensitivity.spv`: 객관적 영향점 기준에 따른 보조 민감도
- `02_output/04_lmm.spv`: LMM 보조 비교
- `02_output/05_conditional.spv`: 보호자 불안 사후2 상호작용 모형의 조건부 효과

`02_final_analysis.spv`는 진단 명령 수정 이전 중간 출력이므로 최종 인용에 사용하지 않는다. 최종 수치 CSV는 `03_tables`, 그림은 `02_output/figures`에 있다. HC3·bootstrap 등 Python 보조 결과는 CSV에 별도로 표시했다.

## 재현 순서

1. IBM SPSS Statistics에서 `01_syntax/02_reproduce_existing.sps`로 기존 결과를 재현한다.
2. `01_syntax/00_run_final.sps`를 실행한다. 자료 확인→기술통계→baseline→RM-ANOVA→ANCOVA 진단→변화량 순이다.
3. `01_syntax/00_run_sensitivity.sps`, `09_lmm_supplement.sps`, `10_conditional_anxiety.sps`를 실행한다.
4. Python 보조 분석은 `analysis_core.py` → `analysis_followup.py` 순으로 실행한다. `11_python_supplement.sps`는 같은 스크립트를 호출하는 편의 래퍼이며 래퍼 자체는 실행 검증하지 않았다. 실제 수치는 Python 스크립트를 직접 실행하여 검증했다.
5. 결과 HTML을 `parse_viewer.py`로 파싱한 뒤 `final_qa.py`로 수치를 대조한다. `make_figures.py`, `write_reports.py`, `finish_delivery.py` 순으로 그림·문서를 생성한다.

경로는 현재 PC의 `C:/projects/박희진` 및 설치 Python/SPSS에 맞춰져 있다. 다른 PC에서는 경로와 패키지 설치를 조정해야 한다. Python 패키지는 `02_output/python_packages`에서 로드한다. 출력 재실행 전에는 저장 대상과 같은 SPV 파일을 Viewer에서 닫아 파일 잠금을 해제한다. 입력 수정본은 `02_output/revision2_20260916/received_RAW_DATA.xlsx`이며 `00_original`은 쓰기 대상이 아니다.

전체자료가 주 분석이며 영향점 삭제 결과는 진단 목적이다. 삭제로 유의성을 만드는 선택을 하지 않았다. 비무작위·비동시 설계이므로 보정 결과를 곧바로 인과효과로 해석하지 않는다.
